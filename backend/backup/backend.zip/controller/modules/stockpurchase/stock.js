const Stock = require("../../../model/modules/stockpurchase/stock");
const User = require("../../../model/login/auth");
const ErrorHandler = require("../../../utils/errorhandler");
const catchAsyncErrors = require("../../../middleware/catchAsyncError");

//get All Stocks =>/api/stock
exports.getAllStock = catchAsyncErrors(async (req, res, next) => {
  let stock;
  try {
    stock = await Stock.find();
  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!stock) {
    return next(new ErrorHandler("Stock not found!", 404));
  }
  return res.status(200).json({
    stock,
  });
});

exports.getAllStockAccess = catchAsyncErrors(async (req, res, next) => {
  let stock;
  try {
    const { assignbranch } = req.body;
    let filterQuery = {};

    // Construct the filter query based on the assignbranch array
    const branchFilter = assignbranch.map((branchObj) => ({
      branch: branchObj.branch,
      company: branchObj.company,
      unit: branchObj.unit,
    }));

    // Use $or to filter incomes that match any of the branch, company, and unit combinations
    // if (branchFilter.length > 0) {
    filterQuery = { $or: branchFilter };

    // filterQuery.$or = [
    //   { requestmode: "Stock Material" },
    //   { status: "Transfer" }
    // ];

    console.log(filterQuery, "filter")
    // }
    stock = await Stock.find(filterQuery
      //   , {
      //   company: 1, branch: 1,
      //   unit: 1, floor: 1, area: 1, location: 1, asset: 1, material: 1, requestmode: 1
      //   , gstno: 1, assettype: 1, producthead: 1, productdetails: 1, productname: 1,
      //   vendorname: 1, billno: 1, billdate: 1, quantity: 1, uom: 1, rate: 1, warrantydetails: 1, warranty: 1, purchasedate: 1, asset: 1, assettype: 1,
      //   vendor: 1, vendorgroup: 1

      // }
    );
    console.log(stock, "data")
  } catch (err) {
    console.log(err, "sdf")
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!stock) {
    return next(new ErrorHandler("Stock not found!", 404));
  }
  return res.status(200).json({
    stock,
  });
});



//create new stock => /api/stock/new
exports.addStock = catchAsyncErrors(async (req, res, next) => {
  let astock = await Stock.create(req.body);
  return res.status(200).json({
    message: "Successfully added!",
  });
});

// get Single stock=> /api/stock/:id
exports.getSingleStock = catchAsyncErrors(async (req, res, next) => {
  const id = req.params.id;
  let sstock = await Stock.findById(id);
  if (!sstock) {
    return next(new ErrorHandler("Stock not found", 404));
  }
  return res.status(200).json({
    sstock,
  });
});
//update stock by id => /api/stock/:id
exports.updateStock = catchAsyncErrors(async (req, res, next) => {
  const id = req.params.id;
  let ustock = await Stock.findByIdAndUpdate(id, req.body);
  if (!ustock) {
    return next(new ErrorHandler("Stock not found", 404));
  }

  return res.status(200).json({ message: "Updated successfully" });
});
//delete stock by id => /api/stock/:id
exports.deleteStock = catchAsyncErrors(async (req, res, next) => {
  const id = req.params.id;
  let dstock = await Stock.findByIdAndRemove(id);
  if (!dstock) {
    return next(new ErrorHandler("Stock not found", 404));
  }

  return res.status(200).json({ message: "Deleted successfully" });
});

exports.Stocktrasnferfilter = catchAsyncErrors(async (req, res, next) => {
  let stocks;
  try {
    stocks = await Stock.find({ productname: req.body.productname, branch: req.body.branch, producthead: req.body.producthead }, { productname: 1, producthead: 1, quantity: 1 });
  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!stocks) {
    return next(new ErrorHandler("Stock not found!", 404));
  }
  return res.status(200).json({
    stocks,
  });
});


exports.getAllStockPurchaseLimitedTransfer = catchAsyncErrors(async (req, res, next) => {
  let stock;
  try {

    stock = await Stock.find({ status: "Transfer" },
      { requestmode: 1, company: 1, status: 1, branch: 1, unit: 1, floor: 1, area: 1, location: 1, productname: 1, stockmaterialarray: 1, quantity: 1 });

  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!stock) {
    return next(new ErrorHandler("Stock not found!", 404));
  }
  return res.status(200).json({
    stock,
  });
});

exports.getAllStockPurchaseLimitedTransferLog = catchAsyncErrors(async (req, res, next) => {
  let stock;
  try {

    stock = await Stock.find({ status: "Transfer", company: req.body.company, branch: req.body.branch, unit: req.body.unit, floor: req.body.floor, area: req.body.area, location: req.body.location },
      { requestmode: 1, company: 1, status: 1, branch: 1, unit: 1, floor: 1, area: 1, location: 1, productname: 1, stockmaterialarray: 1, quantity: 1, addedby: 1 });

  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!stock) {
    return next(new ErrorHandler("Stock not found!", 404));
  }
  return res.status(200).json({
    stock,
  });
});





exports.getAllStockPurchaseLimited = catchAsyncErrors(async (req, res, next) => {
  let stock;
  try {

    stock = await Stock.find({
      requestmode: req.body.assetmat, company: req.body.companyto,
      branch: { $in: req.body.branchto }, unit: { $in: req.body.unitto },
      handover: { $ne: "handover" }
    },
      {
        requestmode: 1, company: 1, branch: 1, unit: 1,
        asset: 1, assettype: 1, component: 1, floor: 1, area: 1, location: 1, productname: 1, stockmaterialarray: 1, quantity: 1
      });


  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!stock) {
    return next(new ErrorHandler("Stock not found!", 404));
  }
  return res.status(200).json({
    stock,
  });
});


exports.getAllStockPurchaseLimitedHandover = catchAsyncErrors(async (req, res, next) => {
  let stock;
  try {

    stock = await Stock.find({ handover: "handover" },
      { company: 1, branch: 1, unit: 1, floor: 1, area: 1, location: 1, productname: 1, countquantity: 1, employeenameto: 1 });

  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!stock) {
    return next(new ErrorHandler("Stock not found!", 404));
  }
  return res.status(200).json({
    stock,
  });
});


exports.getAllStockPurchaseLimitedHandoverTodo = catchAsyncErrors(async (req, res, next) => {
  let stock;
  try {

    stock = await Stock.find({
      handover: "handover", productname: req.body.productname, branch: req.body.branch, unit: req.body.unit, floor: req.body.floor, area: req.body.area,
      location: req.body.location
    },
      { company: 1, branch: 1, unit: 1, floor: 1, area: 1, location: 1, productname: 1, countquantity: 1, employeenameto: 1, addedby: 1 });

  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!stock) {
    return next(new ErrorHandler("Stock not found!", 404));
  }
  return res.status(200).json({
    stock,
  });
});


exports.getAllStockPurchaseLimitedHandoverTodoReturn = catchAsyncErrors(async (req, res, next) => {
  let stock;
  try {

    stock = await Stock.find({
      handover: "return", productname: req.body.productname, branch: req.body.branch, unit: req.body.unit, floor: req.body.floor, area: req.body.area,
      location: req.body.location
    },
      { company: 1, branch: 1, unit: 1, floor: 1, area: 1, location: 1, productname: 1, countquantity: 1, employeenameto: 1, addedby: 1 });

  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!stock) {
    return next(new ErrorHandler("Stock not found!", 404));
  }
  return res.status(200).json({
    stock,
  });
});



exports.getAllStockPurchaseLimitedHandoverandReturn = catchAsyncErrors(async (req, res, next) => {
  let stock;
  try {

    stock = await Stock.find({
      handover: { $in: ["handover", "return"] }, productname: req.body.productname, branch: req.body.branch, unit: req.body.unit, floor: req.body.floor, area: req.body.area,
      location: req.body.location
    },
      { company: 1, branch: 1, unit: 1, floor: 1, area: 1, location: 1, productname: 1, countquantity: 1, employeenameto: 1, addedby: 1, handover: 1 });
  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!stock) {
    return next(new ErrorHandler("Stock not found!", 404));
  }
  return res.status(200).json({
    stock,
  });
});

exports.getAllStockPurchaseLimitedReturn = catchAsyncErrors(async (req, res, next) => {
  let stock;
  try {

    stock = await Stock.find({ handover: "return" },
      { company: 1, branch: 1, unit: 1, floor: 1, area: 1, location: 1, productname: 1, countquantity: 1 });
  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!stock) {
    return next(new ErrorHandler("Stock not found!", 404));
  }
  return res.status(200).json({
    stock,
  });
});


exports.getOverallStockTableSort = catchAsyncErrors(async (req, res, next) => {
  const { page, pageSize, searchQuery } = req.body;

  let allusers;
  let totalProjects, paginatedData, isEmptyData, result;

  try {
    // const query = searchQuery ? { companyname: { $regex: searchQuery, $options: 'i' } } : {};
    const anse = await Stock.find()
    const searchOverTerms = searchQuery?.toLowerCase()?.split(" ");
    const filteredDatas = anse?.filter((item, index) => {
      const itemString = JSON.stringify(item)?.toLowerCase();
      return searchOverTerms.every((term) => itemString.includes(term));
    })
    isEmptyData = searchOverTerms?.every(item => item.trim() === '');
    const pageSized = parseInt(pageSize);
    const pageNumberd = parseInt(page);

    paginatedData = filteredDatas.slice((pageNumberd - 1) * pageSized, pageNumberd * pageSize);

    totalProjects = await Stock.countDocuments();

    allusers = await Stock.find()
      .skip((page - 1) * pageSize)
      .limit(parseInt(pageSize));

    result = isEmptyData ? allusers : paginatedData

  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  // return res.status(200).json({ count: allusers.length, allusers });
  return res.status(200).json({
    allusers,
    totalProjects,
    paginatedData,
    result,
    currentPage: (isEmptyData ? page : 1),
    totalPages: Math.ceil((isEmptyData ? totalProjects : paginatedData?.length) / pageSize),
  });
});
