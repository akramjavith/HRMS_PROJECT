const Employeeasset = require("../../../model/modules/account/employeeassetdistribution");
const ErrorHandler = require("../../../utils/errorhandler");
const catchAsyncErrors = require("../../../middleware/catchAsyncError");

//get All Employeeasset =>/api/Employeeasset
exports.getAllEmployeeasset = catchAsyncErrors(async (req, res, next) => {
  let employeeassets;
  try {
    employeeassets = await Employeeasset.find();
  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!employeeassets) {
    return next(new ErrorHandler("Employeeasset not found!", 404));
  }
  return res.status(200).json({
    employeeassets,
  });
});

exports.getAllEmployeeassetAccess = catchAsyncErrors(async (req, res, next) => {
  let employeeassets;
  try {
    const { assignbranch } = req.body;
    let filterQuery = {};
    // Construct the filter query based on the assignbranch array
    const branchFilter = assignbranch.map((branchObj) => ({
      branch: branchObj.branch,
      company: branchObj.company,
      unit: branchObj.unit,
    }));
    const branchFilterTo = assignbranch.map((branchObj) => ({
      branchto: branchObj.branch,
      companyto: branchObj.company,
      unitto: branchObj.unit,
    }));

    // Use $or to filter incomes that match any of the branch, company, and unit combinations
    // Use $or to filter incomes that match any of the branch, company, and unit combinations
    if (branchFilter.length > 0 || branchFilterTo.length > 0) {
      filterQuery = {
        $or: [...branchFilter, ...branchFilterTo],
      };
    }
    employeeassets = await Employeeasset.find(filterQuery);
  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!employeeassets) {
    return next(new ErrorHandler("Employeeasset not found!", 404));
  }
  return res.status(200).json({
    employeeassets,
  });
});

//create new Employeeasset => /api/Employeeasset/new
exports.addEmployeeasset = catchAsyncErrors(async (req, res, next) => {
  // let checkmain = await Addexists.findOne({ name: req.body.name });
  // if (checkmain) {
  //     return next(new ErrorHandler('Name already exist!', 400));
  // }
  let aEmployeeasset = await Employeeasset.create(req.body);
  return res.status(200).json({
    message: "Successfully added!",
  });
});

// get Single Employeeasset => /api/Employeeasset/:id
exports.getSingleEmployeeasset = catchAsyncErrors(async (req, res, next) => {
  const id = req.params.id;
  let semployeeasset = await Employeeasset.findById(id);
  if (!semployeeasset) {
    return next(new ErrorHandler("Employeeasset not found", 404));
  }
  return res.status(200).json({
    semployeeasset,
  });
});

//update Employeeasset by id => /api/Employeeasset/:id
exports.updateEmployeeasset = catchAsyncErrors(async (req, res, next) => {
  const id = req.params.id;
  let uemployeeasset = await Employeeasset.findByIdAndUpdate(id, req.body);
  if (!uemployeeasset) {
    return next(new ErrorHandler("Employeeasset not found", 404));
  }

  return res.status(200).json({ message: "Updated successfully" });
});

//delete Employeeasset by id => /api/Employeeasset/:id
exports.deleteEmployeeasset = catchAsyncErrors(async (req, res, next) => {
  const id = req.params.id;
  let demployeeasset = await Employeeasset.findByIdAndRemove(id);
  if (!demployeeasset) {
    return next(new ErrorHandler("Employeeasset not found", 404));
  }

  return res.status(200).json({ message: "Deleted successfully" });
});


exports.getAllEmployeeassetAccessHome = catchAsyncErrors(async (req, res, next) => {
  let employeeassets;
  try {


    employeeassets = await Employeeasset.countDocuments();
  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!employeeassets) {
    return next(new ErrorHandler("Employeeasset not found!", 404));
  }
  return res.status(200).json({
    employeeassets,
  });
});