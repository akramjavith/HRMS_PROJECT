const Stockmanage = require("../../../model/modules/stockpurchase/stockmanage");
const ErrorHandler = require("../../../utils/errorhandler");
const catchAsyncErrors = require("../../../middleware/catchAsyncError");

//get All Stockmanages =>/api/stockmanage
exports.getAllStockmanage = catchAsyncErrors(async (req, res, next) => {
  let stockmanage;
  try {
    stockmanage = await Stockmanage.find();
  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!stockmanage) {
    return next(new ErrorHandler("Stockmanage not found!", 404));
  }
  return res.status(200).json({
    stockmanage,
  });
});

exports.getAllStockmanageAccess = catchAsyncErrors(async (req, res, next) => {
  let stockmanage;
  try {
    const { assignbranch } = req.body;
    let filterQuery = {};
    // Construct the filter query based on the assignbranch array
    const branchFilter = assignbranch.map((branchObj) => ({
      branch: branchObj.branch,
      company: branchObj.company,
      unit: branchObj.unit,
    }));

    // Use $or to filter incomes that match any of the branch, company, and unit combinations
    // if (branchFilter.length > 0) {
    filterQuery = { $or: branchFilter };
    // }
    stockmanage = await Stockmanage.find(filterQuery);
  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!stockmanage) {
    return next(new ErrorHandler("Stockmanage not found!", 404));
  }
  return res.status(200).json({
    stockmanage,
  });
});

exports.getAllStockmanageFiltered = catchAsyncErrors(async (req, res, next) => {
  let stockmanage;
  try {
    stockmanage = await Stockmanage.find({ updating: "" });
  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!stockmanage) {
    return next(new ErrorHandler("Stockmanage not found!", 404));
  }
  return res.status(200).json({
    stockmanage,
  });
});

exports.getAllStockmanageFilteredAccess = catchAsyncErrors(async (req, res, next) => {
  let stockmanage, query;
  try {
    const { assignbranch } = req.body;
    let filterQuery = {};
    // Construct the filter query based on the assignbranch array
    const branchFilter = assignbranch.map((branchObj) => ({
      branch: branchObj.branch,
      company: branchObj.company,
      unit: branchObj.unit,
    }));

    // Use $or to filter incomes that match any of the branch, company, and unit combinations
    // if (branchFilter.length > 0) {
    filterQuery = { $or: branchFilter };
    // }

    query = {
      updating: "",
      ...filterQuery,

    }
    stockmanage = await Stockmanage.find(query);
  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!stockmanage) {
    return next(new ErrorHandler("Stockmanage not found!", 404));
  }
  return res.status(200).json({
    stockmanage,
  });
});

//create new stockmanage => /api/stockmanage/new
exports.addStockmanage = catchAsyncErrors(async (req, res, next) => {
  let astockmanage = await Stockmanage.create(req.body);
  return res.status(200).json({
    message: "Successfully added!",
  });
});

// get Single stockmanage=> /api/stockmanage/:id
exports.getSingleStockmanage = catchAsyncErrors(async (req, res, next) => {
  const id = req.params.id;
  let sstockmanage = await Stockmanage.findById(id);
  if (!sstockmanage) {
    return next(new ErrorHandler("Stockmanage not found", 404));
  }
  return res.status(200).json({
    sstockmanage,
  });
});
//update stockmanage by id => /api/stockmanage/:id
exports.updateStockmanage = catchAsyncErrors(async (req, res, next) => {
  const id = req.params.id;
  let ustockmanage = await Stockmanage.findByIdAndUpdate(id, req.body);
  if (!ustockmanage) {
    return next(new ErrorHandler("Stockmanage not found", 404));
  }

  return res.status(200).json({ message: "Updated successfully" });
});
//delete stockmanage by id => /api/stockmanage/:id
exports.deleteStockmanage = catchAsyncErrors(async (req, res, next) => {
  const id = req.params.id;
  let dstockmanage = await Stockmanage.findByIdAndRemove(id);
  if (!dstockmanage) {
    return next(new ErrorHandler("Stockmanage not found", 404));
  }

  return res.status(200).json({ message: "Deleted successfully" });
});
