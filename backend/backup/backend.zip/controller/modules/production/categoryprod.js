const Categoryprod = require("../../../model/modules/production/categoryprodmodel");
const ErrorHandler = require("../../../utils/errorhandler");
const catchAsyncErrors = require("../../../middleware/catchAsyncError");

// get All categoryprod => /api/categoryprod
exports.getAllCategoryprod = catchAsyncErrors(async (req, res, next) => {
  let categoryprod;
  try {
    categoryprod = await Categoryprod.find();
  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!categoryprod) {
    return next(new ErrorHandler("Categoryprod not found!", 404));
  }
  return res.status(200).json({
    // count: products.length,
    categoryprod,
  });
});

exports.CategoryprodSort = catchAsyncErrors(async (req, res, next) => {
  let totalProjects, result, totalPages, currentPage;

  const { page, pageSize } = req.body;
  try {

    totalProjects = await Categoryprod.countDocuments();

    result = await Categoryprod.find()
      .skip((page - 1) * pageSize)
      .limit(parseInt(pageSize));

  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }

  return res.status(200).json({
    totalProjects,
    result,
    currentPage: page,
    totalPages: Math.ceil(totalProjects / pageSize),
  });
});
// get All categoryprod => /api/categoryprod
exports.getAllCategoryprodLimited = catchAsyncErrors(async (req, res, next) => {
  let categoryprod;
  try {
    categoryprod = await Categoryprod.find({}, { name: 1, project: 1, flagstatus: 1, mismatchmode: 1 });
  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!categoryprod) {
    return next(new ErrorHandler("Categoryprod not found!", 404));
  }
  return res.status(200).json({
    // count: products.length,
    categoryprod,
  });
});

// Create new categoryprod=> /api/categoryprod/new
exports.addCategoryprod = catchAsyncErrors(async (req, res, next) => {
  try {
    // Create new Categoryprod entry
    let acategoryprod = await Categoryprod.create(req.body);
    return res.status(200).json({
      message: 'Successfully added!',
      data: acategoryprod
    });
  } catch (error) {
    // Pass any errors to the centralized error handler
    next(error);
  }
});

// get Signle categoryprod => /api/categoryprod/:id
exports.getSingleCategoryprod = catchAsyncErrors(async (req, res, next) => {
  const id = req.params.id;

  let scategoryprod = await Categoryprod.findById(id);

  if (!scategoryprod) {
    return next(new ErrorHandler("Categoryprod not found!", 404));
  }
  return res.status(200).json({
    scategoryprod,
  });
});

// update categoryprod by id => /api/categoryprod/:id
exports.updateCategoryprod = catchAsyncErrors(async (req, res, next) => {
  const id = req.params.id;
  let ucategoryprod = await Categoryprod.findByIdAndUpdate(id, req.body);
  if (!ucategoryprod) {
    return next(new ErrorHandler("Categoryprod not found!", 404));
  }
  return res.status(200).json({ message: "Updated successfully" });
});

// delete categoryprod by id => /api/categoryprod/:id
exports.deleteCategoryprod = catchAsyncErrors(async (req, res, next) => {
  const id = req.params.id;

  let dcategoryprod = await Categoryprod.findByIdAndRemove(id);

  if (!dcategoryprod) {
    return next(new ErrorHandler("Categoryprod not found!", 404));
  }
  return res.status(200).json({ message: "Deleted successfully" });
});

// get All ProductionUpload => /api/productionuploads
exports.checkCategoryForProdUpload = catchAsyncErrors(async (req, res, next) => {
  let categoryprod;
  try {
    const { project, category } = req.body;
    categoryprod = await Categoryprod.find({ project: project, name: { $in: category } }, { project: 1, name: 1, flagstatus: 1 });
  } catch (err) {
    console.log(err.message);
  }
  return res.status(200).json({
    categoryprod,
  });
});



// get All categoryprod => /api/categoryprod
exports.categoryProdLimitedReportsMulti = catchAsyncErrors(async (req, res, next) => {
  let categoryprod;
  try {
    console.log(req.body, "vvfs")
    categoryprod = await Categoryprod.find({ project: { $in: req.body.projectvendor } }, { name: 1, _id: 0 });

  } catch (err) {
    console.log(err.message);
  }
  if (!categoryprod) {
    return next(new ErrorHandler("Categoryprod not found!", 404));
  }
  return res.status(200).json({
    // count: products.length,
    categoryprod,
  });
});