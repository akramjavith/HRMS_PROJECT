const Stock = require("../../../model/modules/stockpurchase/stock");
const User = require("../../../model/login/auth");
const Manualstock = require("../../../model/modules/stockpurchase/manualstockentry");
const ErrorHandler = require("../../../utils/errorhandler");
const catchAsyncErrors = require("../../../middleware/catchAsyncError");
const ExcelJS = require("exceljs");
const { PassThrough } = require("stream");
const PDFDocument = require('pdfkit');


function createFilterCondition(column, condition, value) {
  switch (condition) {
    case "Contains":
      return { [column]: new RegExp(value, 'i') };
    case "Does Not Contain":
      return { [column]: { $not: new RegExp(value, 'i') } };
    case "Equals":
      return { [column]: value };
    case "Does Not Equal":
      return { [column]: { $ne: value } };
    case "Begins With":
      return { [column]: new RegExp(`^${value}`, 'i') };
    case "Ends With":
      return { [column]: new RegExp(`${value}$`, 'i') };
    case "Blank":
      return { [column]: { $exists: false } };
    case "Not Blank":
      return { [column]: { $exists: true } };
    default:
      return {};
  }
}

//get All Stocks =>/api/stock
exports.getAllStock = catchAsyncErrors(async (req, res, next) => {
  let stock;
  try {
    stock = await Stock.find();
  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!stock) {
    return next(new ErrorHandler("Stock not found!", 404));
  }
  return res.status(200).json({
    stock,
  });
});

exports.getAllStockBillno = catchAsyncErrors(async (req, res, next) => {
  let stock;
  try {
    stock = await Stock.countDocuments({ billno: req.body.billno });
    console.log(stock, "stock")
  } catch (err) {

    return next(new ErrorHandler("Records not found!", 404));
  }

  return res.status(200).json({
    stock,
  });
});



exports.getAllStockAccess = catchAsyncErrors(async (req, res, next) => {
  const { page, pageSize, assignbranch, allFilters, logicOperator, searchQuery, requestmode, company, branch, unit } = req.body;
  // console.log(req.body, "bodypurchase")
  let query = {};
  // Construct the filter query based on the assignbranch array
  const branchFilter = assignbranch.map((branchObj) => ({
    branch: branchObj.branch,
    company: branchObj.company,
    unit: branchObj.unit,
  }));

  query = {
    $or: branchFilter,
    requestmode: "Asset Material"

  };

  if (company && company?.length > 0) {
    query.company = { $in: company }
  }

  if (branch && branch?.length > 0) {
    query.branch = { $in: branch }
  }
  if (unit && unit?.length > 0) {
    query.unit = { $in: unit }
  }



  // console.log(query, "query")

  let queryoverall = {};
  // Construct the filter query based on the assignbranch array
  const branchFilterOverall = assignbranch.map((branchObj) => ({
    branch: branchObj.branch,
    company: branchObj.company,
    unit: branchObj.unit,
  }));

  queryoverall = { $or: branchFilterOverall, requestmode: "Asset Material" };
  if (company && company?.length > 0) {
    queryoverall.company = { $in: company }
  }
  if (branch && branch?.length > 0) {
    queryoverall.branch = { $in: branch }
  }
  if (unit && unit?.length > 0) {
    queryoverall.unit = { $in: unit }
  }


  let conditions = [];

  // Advanced search filter
  if (allFilters && allFilters.length > 0) {
    allFilters.forEach(filter => {
      // console.log(filter, "filter")
      if (filter.column && filter.condition && (filter.value || ["Blank", "Not Blank"].includes(filter.condition))) {
        if (filter.column == "purchasedate" || filter.column == "billdate") {
          const [day, month, year] = filter.value.split("/")
          let formattedValue = `${year}-${month}-${day}`
          conditions.push(createFilterCondition(filter.column, filter.condition, formattedValue));
        }
        else {

          conditions.push(createFilterCondition(filter.column, filter.condition, filter.value));
        }
      }
    });
  }



  if (searchQuery && searchQuery !== undefined) {
    const searchTermsArray = searchQuery.split(" ").filter(term => term.trim() !== ""); // Remove empty terms
    const regexTerms = searchTermsArray.map((term) => {
      if (!isNaN(term)) {
        return parseInt(term, 10); // Convert numeric term to Number
      }

      // Check if the term is in the date format DD/MM/YYYY
      const dateRegex = /^\d{2}\/\d{2}\/\d{4}$/;
      if (dateRegex.test(term)) {
        // Convert DD/MM/YYYY to YYYY-MM-DD
        const [day, month, year] = term.split("/");
        const formattedDate = `${year}-${month}-${day}`;
        return new RegExp(formattedDate, "i");
      }

      return new RegExp(term, "i"); // Default case: string regex
    });

    const regexFields = [
      "company",
      "branch",
      "unit",
      "floor",
      "area",
      "location",
      "requestmode",
      "vendorgroup",
      "vendor",
      "gstno",
      "billno",
      "assettype",
      "producthead",
      "productname",
      "warranty",
      "purchasedate",
      "productdetails",
      "warrantydetails",
      "quantity",
      "uom",
      "rate",
      "billdate",
    ];

    const orConditions = regexTerms.map((regex) => {


      // General regex case
      return {
        $or: [
          ...regexFields.map(field => ({ [field]: regex })),


          // {
          //   // Add condition for array `stockmaterialarray`
          //   stockmaterialarray: {
          //     $elemMatch: {
          //       $or: [
          //         { uomnew: regex },
          //         { quantitynew: regex },
          //         { materialnew: regex },
          //         { productdetailsnew: regex },
          //         { uomcodenew: regex }
          //       ],
          //     },
          //   },
          // },
        ],
      };
    });

    query = {
      $and: [
        { requestmode: "Asset Material" },
        {
          $or: assignbranch.map((branchObj) => ({
            branch: branchObj.branch,
            company: branchObj.company,
            unit: branchObj.unit,
          })),
        },
        ...orConditions,
      ],
    };
  }

  // console.log(query, "query")
  // Apply logicOperator to combine conditions
  if (conditions.length > 0) {
    if (logicOperator === "AND") {
      query.$and = conditions;
    } else if (logicOperator === "OR") {
      query.$or = conditions;
    }
  }
  // console.log(conditions, "conditions")
  try {

    // const totalProjects = await Stock.countDocuments(query);

    // const totalProjectsData = await Stock.find(queryoverall
    //   , {
    //     company: 1,
    //     branch: 1,
    //     unit: 1,
    //     floor: 1,
    //     area: 1,
    //     location: 1,
    //     requestmode: 1,
    //     vendorgroup: 1,
    //     vendor: 1,
    //     gstno: 1,
    //     billno: 1,
    //     assettype: 1,
    //     producthead: 1,
    //     productname: 1,
    //     warranty: 1,
    //     purchasedate: 1,
    //     productdetails: 1,
    //     warrantydetails: 1,
    //     quantity: 1,
    //     uom: 1,
    //     rate: 1,
    //     billdate: 1

    //   }
    // );

    // const result = await Stock.find(query
    //   , {
    //     company: 1,
    //     branch: 1,
    //     unit: 1,
    //     floor: 1,
    //     area: 1,
    //     location: 1,
    //     requestmode: 1,
    //     vendorgroup: 1,
    //     vendor: 1,
    //     gstno: 1,
    //     billno: 1,
    //     assettype: 1,
    //     producthead: 1,
    //     productname: 1,
    //     warranty: 1,
    //     purchasedate: 1,
    //     productdetails: 1,
    //     warrantydetails: 1,
    //     quantity: 1,
    //     uom: 1,
    //     rate: 1,
    //     billdate: 1
    //   }
    // ).select("")
    //   .lean()
    //   .skip((page - 1) * pageSize)
    //   .limit(parseInt(pageSize))
    //   .exec();
    const [totalProjects, result, totalProjectsData,] = await Promise.all([
      Stock.countDocuments(query),



      Stock.find(query, {
        company: 1,
        branch: 1,
        unit: 1,
        floor: 1,
        area: 1,
        location: 1,
        requestmode: 1,
        vendorgroup: 1,
        vendor: 1,
        gstno: 1,
        billno: 1,
        assettype: 1,
        producthead: 1,
        productname: 1,
        warranty: 1,
        purchasedate: 1,
        productdetails: 1,
        warrantydetails: 1,
        quantity: 1,
        uom: 1,
        rate: 1,
        billdate: 1
      })
        .select("")
        .lean()
        .skip((page - 1) * pageSize)
        .limit(parseInt(pageSize))
        .exec()
    ]);

    // Stock.find(queryoverall, {
    //   company: 1,
    //   branch: 1,
    //   unit: 1,
    //   floor: 1,
    //   area: 1,
    //   location: 1,
    //   requestmode: 1,
    //   vendorgroup: 1,
    //   vendor: 1,
    //   gstno: 1,
    //   billno: 1,
    //   assettype: 1,
    //   producthead: 1,
    //   productname: 1,
    //   warranty: 1,
    //   purchasedate: 1,
    //   productdetails: 1,
    //   warrantydetails: 1,
    //   quantity: 1,
    //   uom: 1,
    //   rate: 1,
    //   billdate: 1
    // }).lean(),


    console.log(result.length, 'resultpurchase')
    res.status(200).json({
      totalProjects,
      totalProjectsData: [],
      result,
      currentPage: page,
      totalPages: Math.ceil(totalProjects / pageSize),
    });
  } catch (err) {
    // console.log(err, "stock")
    return next(new ErrorHandler("Records not found!", 404));
  }
});


exports.getAllStockAccessStock = catchAsyncErrors(async (req, res, next) => {
  const { page, pageSize, assignbranch, allFilters, logicOperator, searchQuery, company, branch, unit } = req.body;

  let query = {};
  // Construct the filter query based on the assignbranch array
  const branchFilter = assignbranch.map((branchObj) => ({
    branch: branchObj.branch,
    company: branchObj.company,
    unit: branchObj.unit,
  }));

  query = {
    $or: branchFilter,
    requestmode: "Stock Material",
    // status: "Transfer"
  };
  if (company && company?.length > 0) {
    query.company = { $in: company }
  }

  if (branch && branch?.length > 0) {
    query.branch = { $in: branch }
  }
  if (unit && unit?.length > 0) {
    query.unit = { $in: unit }
  }


  let queryoverall = {};
  // Construct the filter query based on the assignbranch array
  const branchFilterOverall = assignbranch.map((branchObj) => ({
    branch: branchObj.branch,
    company: branchObj.company,
    unit: branchObj.unit,
  }));

  queryoverall = {
    $or: branchFilterOverall, requestmode: "Stock Material"
    // , status: "Transfer"
  };
  if (company && company?.length > 0) {
    queryoverall.company = { $in: company }
  }

  if (branch && branch?.length > 0) {
    queryoverall.branch = { $in: branch }
  }
  if (unit && unit?.length > 0) {
    queryoverall.unit = { $in: unit }
  }


  let conditions = [];

  // Advanced search filter
  if (allFilters && allFilters.length > 0) {
    allFilters.forEach(filter => {
      // console.log(filter, "filter")
      if (filter.column && filter.condition && (filter.value || ["Blank", "Not Blank"].includes(filter.condition))) {
        if (filter.column == "purchasedate" || filter.column == "billdate") {
          const [day, month, year] = filter.value.split("/")
          let formattedValue = `${year}-${month}-${day}`
          conditions.push(createFilterCondition(filter.column, filter.condition, formattedValue));
        }
        else {

          conditions.push(createFilterCondition(filter.column, filter.condition, filter.value));
        }
      }
    });
  }



  if (searchQuery && searchQuery !== undefined) {
    const searchTermsArray = searchQuery.split(" ").filter(term => term.trim() !== ""); // Remove empty terms
    const regexTerms = searchTermsArray.map((term) => {
      if (!isNaN(term)) {
        return parseInt(term, 10); // Convert numeric term to Number
      }

      // Check if the term is in the date format DD/MM/YYYY
      const dateRegex = /^\d{2}\/\d{2}\/\d{4}$/;
      if (dateRegex.test(term)) {
        // Convert DD/MM/YYYY to YYYY-MM-DD
        const [day, month, year] = term.split("/");
        const formattedDate = `${year}-${month}-${day}`;
        return new RegExp(formattedDate, "i");
      }

      return new RegExp(term, "i"); // Default case: string regex
    });

    const regexFields = [
      "company",
      "branch",
      "unit",
      "floor",
      "area",
      "location",
      "requestmode",
      "stockcategory",
      "stocksubcategory",
      "quantitynew",
      "uomnew",
      "materialnew",
      "productdetailsnew",
      "gstno",
      "billno",
      "warrantydetails",
      "warranty",
      "purchasedate",
      "billdate",
      "rate",
      "vendorgroup",
      "vendor",
    ];

    const orConditions = regexTerms.map((regex) => {


      // General regex case
      return {
        $or: [
          ...regexFields.map(field => ({ [field]: regex })),
          {
            // Add condition for array `stockmaterialarray`
            stockmaterialarray: {
              $elemMatch: {
                $or: [
                  { uomnew: regex },
                  { quantitynew: regex },
                  { materialnew: regex },
                  { productdetailsnew: regex },
                  { uomcodenew: regex }
                ],
              },
            },
          },
        ],
      };
    });

    query = {
      $and: [
        { requestmode: "Stock Material" },
        {
          $or: assignbranch.map((branchObj) => ({
            branch: branchObj.branch,
            company: branchObj.company,
            unit: branchObj.unit,
          })),
        },
        ...orConditions,
      ],
    };
  }
  // Apply logicOperator to combine conditions
  if (conditions.length > 0) {
    if (logicOperator === "AND") {
      query.$and = conditions;
    } else if (logicOperator === "OR") {
      query.$or = conditions;
    }
  }
  // console.log(conditions, "conditions")
  try {

    const [totalProjects, result, totalProjectsData,] = await Promise.all([
      Stock.countDocuments(query),



      Stock.find(query, {
        company: 1,
        branch: 1,
        unit: 1,
        floor: 1,
        area: 1,
        location: 1,
        requestmode: 1,
        stockcategory: 1,
        stocksubcategory: 1,
        quantitynew: 1,
        uomnew: 1,
        materialnew: 1,
        productdetailsnew: 1,
        gstno: 1,
        billno: 1,
        warrantydetails: 1,
        warranty: 1,
        purchasedate: 1,
        billdate: 1,
        rate: 1,
        vendorgroup: 1,
        vendor: 1,
        stockmaterialarray: 1,
        quantitynew: 1
      })
        .select("")
        .lean()
        .skip((page - 1) * pageSize)
        .limit(parseInt(pageSize))
        .exec(),

      // Stock.find(queryoverall, {
      //   company: 1,
      //   branch: 1,
      //   unit: 1,
      //   floor: 1,
      //   area: 1,
      //   location: 1,
      //   requestmode: 1,
      //   stockcategory: 1,
      //   stocksubcategory: 1,
      //   quantitynew: 1,
      //   uomnew: 1,
      //   materialnew: 1,
      //   productdetailsnew: 1,
      //   gstno: 1,
      //   billno: 1,
      //   warrantydetails: 1,
      //   warranty: 1,
      //   purchasedate: 1,
      //   billdate: 1,
      //   rate: 1,
      //   vendorgroup: 1,
      //   vendor: 1,
      //   stockmaterialarray: 1,
      //   quantitynew: 1
      // }),


    ]);

    // Now, totalProjects, totalProjectsData, and result are available for use.

    console.log(result.length, 'resultstock')
    res.status(200).json({
      totalProjects,
      totalProjectsData: [],
      result,
      currentPage: page,
      totalPages: Math.ceil(totalProjects / pageSize),
    });
  } catch (err) {
    // console.log(err, "stock")
    return next(new ErrorHandler("Records not found!", 404));
  }
});


//create new stock => /api/stock/new
exports.addStock = catchAsyncErrors(async (req, res, next) => {
  let astock = await Stock.create(req.body);
  return res.status(200).json({
    message: "Successfully added!",
  });
});

// get Single stock=> /api/stock/:id
exports.getSingleStock = catchAsyncErrors(async (req, res, next) => {
  const id = req.params.id;
  let sstock = await Stock.findById(id);
  if (!sstock) {
    return next(new ErrorHandler("Stock not found", 404));
  }
  return res.status(200).json({
    sstock,
  });
});
//update stock by id => /api/stock/:id
exports.updateStock = catchAsyncErrors(async (req, res, next) => {
  const id = req.params.id;
  let ustock = await Stock.findByIdAndUpdate(id, req.body);
  if (!ustock) {
    return next(new ErrorHandler("Stock not found", 404));
  }

  return res.status(200).json({ message: "Updated successfully" });
});
//delete stock by id => /api/stock/:id
exports.deleteStock = catchAsyncErrors(async (req, res, next) => {
  const id = req.params.id;
  let dstock = await Stock.findByIdAndRemove(id);
  if (!dstock) {
    return next(new ErrorHandler("Stock not found", 404));
  }

  return res.status(200).json({ message: "Deleted successfully" });
});

exports.Stocktrasnferfilter = catchAsyncErrors(async (req, res, next) => {
  let stocks;
  try {
    stocks = await Stock.find({ productname: req.body.productname, branch: req.body.branch, producthead: req.body.producthead }, { productname: 1, producthead: 1, quantity: 1 });
  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!stocks) {
    return next(new ErrorHandler("Stock not found!", 404));
  }
  return res.status(200).json({
    stocks,
  });
});


exports.getAllStockPurchaseLimitedTransfer = catchAsyncErrors(async (req, res, next) => {
  let stock;
  try {

    stock = await Stock.find({ status: "Transfer" },
      { requestmode: 1, company: 1, status: 1, branch: 1, unit: 1, floor: 1, area: 1, location: 1, productname: 1, stockmaterialarray: 1, quantity: 1 });

  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!stock) {
    return next(new ErrorHandler("Stock not found!", 404));
  }
  return res.status(200).json({
    stock,
  });
});

exports.getAllStockPurchaseLimitedTransferLog = catchAsyncErrors(async (req, res, next) => {
  let stock;
  try {

    stock = await Stock.find({
      $or: [
        { status: "Transfer", },
        { handover: "handover", requestmode: "Stock Material", productname: req.body.material }
      ],
      company: req.body.company, branch: req.body.branch, unit: req.body.unit, floor: req.body.floor, area: req.body.area, location: req.body.location
    },
      {
        requestmode: 1, company: 1, status: 1, branch: 1, unit: 1, floor: 1, area: 1, location: 1, productname: 1, employeenameto: 1, countquantity: 1,
        stockmaterialarray: 1, quantity: 1, addedby: 1
      });
    // console.log(stock, "viewstock")
  } catch (err) {
    // console.log(err, "viewser")
    return next(new ErrorHandler("Records not found!", 404));
  }
  // if (!stock) {
  //   return next(new ErrorHandler("Stock not found!", 404));
  // }
  return res.status(200).json({
    stock,
  });
});





exports.getAllStockPurchaseLimited = catchAsyncErrors(async (req, res, next) => {
  let stock = [];
  try {

    // stocklimited = await Stock.find({
    //   requestmode: req.body.assetmat, company: req.body.companyto,
    //   branch: { $in: req.body.branchto }, unit: { $in: req.body.unitto },
    //   handover: { $exists: false }
    // },
    //   {
    //     requestmode: 1, company: 1, branch: 1, unit: 1,
    //     floor: 1, area: 1, location: 1, productname: 1, quantity: 1, stockmaterialarray: 1
    //   });

    // manuallimited = await Manualstock.find({
    //   requestmode: req.body.assetmat, company: req.body.companyto,
    //   branch: { $in: req.body.branchto }, unit: { $in: req.body.unitto },
    //   handover: { $exists: false }
    // },
    //   {
    //     requestmode: 1, company: 1, branch: 1, unit: 1,
    //     floor: 1, area: 1, location: 1, productname: 1, quantity: 1, stockmaterialarray: 1
    //   });

    // stock = [...stocklimited, ...manuallimited.map(item =>({...item,type:"Manual"}))]
    const [stocklimited, manuallimited] = await Promise.all([
      Stock.aggregate([
        {
          $match: {
            requestmode: req.body.assetmat,
            company: req.body.companyto,
            branch: { $in: req.body.branchto },
            unit: { $in: req.body.unitto },
            handover: { $exists: false }
          }
        },
        {
          $project: {
            requestmode: 1, company: 1, branch: 1, unit: 1,
            floor: 1, area: 1, location: 1, productname: 1,
            quantity: 1, stockmaterialarray: 1,
            status: { $literal: "Stock" } // Adding status directly
          }
        }
      ]),
      Manualstock.aggregate([
        {
          $match: {
            requestmode: req.body.assetmat,
            company: req.body.companyto,
            branch: { $in: req.body.branchto },
            unit: { $in: req.body.unitto },
            handover: { $exists: false }
          }
        },
        {
          $project: {
            requestmode: 1, company: 1, branch: 1, unit: 1,
            floor: 1, area: 1, location: 1, productname: 1,
            quantity: 1, stockmaterialarray: 1,
            status: { $literal: "Manual" }
          }
        }
      ])
    ]);

    stock = [...stocklimited, ...manuallimited];


    console.log(stock[15], "stocklimited")

  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!stock) {
    return next(new ErrorHandler("Stock not found!", 404));
  }
  return res.status(200).json({
    stock,
  });
});


exports.getAllStockPurchaseLimitedHandover = catchAsyncErrors(async (req, res, next) => {
  let stock = [], stocklimited, manuallimited;
  try {

    // stocklimited = await Stock.find({ handover: "handover" },
    //   { company: 1, branch: 1, unit: 1, floor: 1, area: 1, location: 1, productname: 1, countquantity: 1, employeenameto: 1 });


    // manuallimited = await Manualstock.find({ handover: "handover" },
    //   { company: 1, branch: 1, unit: 1, floor: 1, area: 1, location: 1, productname: 1, countquantity: 1, employeenameto: 1 });


    //   stock = [...stocklimited, ...manuallimited]

    const [stocklimited, manuallimited] = await Promise.all([
      Stock.aggregate([
        {
          $match: { handover: "handover" }
        },
        {
          $project: {
            company: 1, branch: 1, unit: 1, floor: 1, area: 1,
            location: 1, productname: 1, countquantity: 1,
            employeenameto: 1,
            status: { $literal: "Stock" } // Adding status field
          }
        }
      ]),
      Manualstock.aggregate([
        {
          $match: { handover: "handover" }
        },
        {
          $project: {
            company: 1, branch: 1, unit: 1, floor: 1, area: 1,
            location: 1, productname: 1, countquantity: 1,
            employeenameto: 1,
            status: { $literal: "Manual" } // Adding status field
          }
        }
      ])
    ]);

    stock = [...stocklimited, ...manuallimited];



  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!stock) {
    return next(new ErrorHandler("Stock not found!", 404));
  }
  return res.status(200).json({
    stock,
  });
});


exports.getAllStockPurchaseLimitedUsageCount = catchAsyncErrors(async (req, res, next) => {
  let stock = [], stocklimited, manuallimited;
  try {

    // stocklimited = await Stock.find({ handover: "usagecount" },
    //   {
    //     company: 1, branch: 1, unit: 1, floor: 1, area: 1, location: 1, productname: 1, countquantity: 1,
    //     employeenameto: 1, usagedate: 1, usagetime: 1, usercompany: 1, userbranch: 1, userunit: 1,
    //     userfloor: 1, userarea: 1, userlocation: 1, useremployee: 1, userteam: 1, description: 1, filesusagecount: 1, requestmode: 1
    //   });

    // manuallimited = await Manualstock.find({ handover: "usagecount" },
    //   {
    //     company: 1, branch: 1, unit: 1, floor: 1, area: 1, location: 1, productname: 1, countquantity: 1,
    //     employeenameto: 1, usagedate: 1, usagetime: 1, usercompany: 1, userbranch: 1, userunit: 1,
    //     userfloor: 1, userarea: 1, userlocation: 1, useremployee: 1, userteam: 1, description: 1, filesusagecount: 1, requestmode: 1
    //   });

    // stock = [...stocklimited, manuallimited]
    const [stocklimited, manuallimited] = await Promise.all([
      Stock.aggregate([
        {
          $match: { handover: "usagecount" }
        },
        {
          $project: {
            company: 1, branch: 1, unit: 1, floor: 1, area: 1, location: 1, productname: 1, countquantity: 1,
            employeenameto: 1, usagedate: 1, usagetime: 1, usercompany: 1, userbranch: 1, userunit: 1,
            userfloor: 1, userarea: 1, userlocation: 1, useremployee: 1, userteam: 1, description: 1,
            filesusagecount: 1, requestmode: 1,
            status: { $literal: "Stock" } // Adding status field
          }
        }
      ]),
      Manualstock.aggregate([
        {
          $match: { handover: "usagecount" }
        },
        {
          $project: {
            company: 1, branch: 1, unit: 1, floor: 1, area: 1, location: 1, productname: 1, countquantity: 1,
            employeenameto: 1, usagedate: 1, usagetime: 1, usercompany: 1, userbranch: 1, userunit: 1,
            userfloor: 1, userarea: 1, userlocation: 1, useremployee: 1, userteam: 1, description: 1,
            filesusagecount: 1, requestmode: 1,
            status: { $literal: "Manual" } // Adding status field
          }
        }
      ])
    ]);

    stock = [...stocklimited, ...manuallimited];


  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!stock) {
    return next(new ErrorHandler("Stock not found!", 404));
  }
  return res.status(200).json({
    stock,
  });
});

exports.getAllStockPurchaseLimitedReturn = catchAsyncErrors(async (req, res, next) => {
  let stock = [], stocklimited, manuallimited;
  try {

    // stocklimited = await Stock.find({ handover: "return" },
    //   { company: 1, branch: 1, unit: 1, floor: 1, area: 1, location: 1, productname: 1, countquantity: 1 });
    // manuallimited = await Manualstock.find({ handover: "return" },
    //   { company: 1, branch: 1, unit: 1, floor: 1, area: 1, location: 1, productname: 1, countquantity: 1 });
    // stock = [...stocklimited, ...manuallimited]

    const [stocklimited, manuallimited] = await Promise.all([
      Stock.aggregate([
        {
          $match: { handover: "return" }
        },
        {
          $project: {
            company: 1, branch: 1, unit: 1, floor: 1, area: 1, location: 1,
            productname: 1, countquantity: 1,
            status: { $literal: "Stock" } // Adding status field
          }
        }
      ]),
      Manualstock.aggregate([
        {
          $match: { handover: "return" }
        },
        {
          $project: {
            company: 1, branch: 1, unit: 1, floor: 1, area: 1, location: 1,
            productname: 1, countquantity: 1,
            status: { $literal: "Manual" } // Adding status field
          }
        }
      ])
    ]);

    stock = [...stocklimited, ...manuallimited];



  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!stock) {
    return next(new ErrorHandler("Stock not found!", 404));
  }
  return res.status(200).json({
    stock,
  });
});


exports.getAllStockPurchaseLimitedUsageCountNotification = catchAsyncErrors(async (req, res, next) => {
  let stock;
  try {

    stock = await Stock.countDocuments({ employeenameto: req.body.username, handover: "handover" });



  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!stock) {
    return next(new ErrorHandler("Stock not found!", 404));
  }
  return res.status(200).json({
    stock,
  });
});

exports.getAllStockPurchaseLimitedUsageCountCreateList = catchAsyncErrors(async (req, res, next) => {
  let stock;
  try {
    // const query = {}
    // query.handover = "usagecount"
    // query.addedby = { name: req.body.username };

    const query = {
      "addedby.name": req.body.username,
      handover: "usagecount",
      company: req.body.company, branch: req.body.branch, unit: req.body.unit, floor: req.body.floor, area: req.body.area,
      location: req.body.location, productname: req.body.productname, requestmode: req.body.requestmode
    };

    // console.log(query, "querycreae")

    stock = await Stock.find(query,
      {
        company: 1, branch: 1, unit: 1, floor: 1, area: 1, location: 1, productname: 1, countquantity: 1,
        employeenameto: 1, usagedate: 1, usagetime: 1, description: 1, usercompany: 1, userbranch: 1, userunit: 1,
        userfloor: 1, userarea: 1, userlocation: 1, useremployee: 1, userteam: 1, description: 1, requestmode: 1, filesusagecount: 1, addedby: 1
      });
    // console.log(stock.length, "stocknotsdfsdf")

  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!stock) {
    return next(new ErrorHandler("Stock not found!", 404));
  }
  return res.status(200).json({
    stock,
  });
});

exports.getAllStockPurchaseLimitedUsageCountNotificationList = catchAsyncErrors(async (req, res, next) => {
  let stock;
  try {
    const query = {}
    query.employeenameto = { $in: req.body.username };
    // query.requestmode = { $in: req.body.assetmat };
    query.handover = {
      $in: ["handover", "usagecount"],

    },


      stock = await Stock.find(query,
        {
          company: 1, branch: 1, unit: 1, floor: 1, area: 1, location: 1, productname: 1, countquantity: 1,
          employeenameto: 1, usagedate: 1, usagetime: 1, description: 1, usercompany: 1, userbranch: 1, userunit: 1,
          userfloor: 1, userarea: 1, userlocation: 1, useremployee: 1, userteam: 1, description: 1, requestmode: 1, filesusagecount: 1
        });
    // console.log(stock.length, "stocknot")

  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!stock) {
    return next(new ErrorHandler("Stock not found!", 404));
  }
  return res.status(200).json({
    stock,
  });
});


exports.getAllStockPurchaseLimitedHandoverTodo = catchAsyncErrors(async (req, res, next) => {
  let stock = [];
  try {

    // stocklimited = await Stock.find({
    //   handover: "handover", productname: req.body.productname, company: req.body.company, branch: req.body.branch, unit: req.body.unit, floor: req.body.floor, area: req.body.area,
    //   location: req.body.location
    // },
    //   {
    //     company: 1, branch: 1, unit: 1, floor: 1, area: 1, location: 1, productname: 1, countquantity: 1, employeenameto: 1,
    //     addedby: 1, usercompany: 1, userbranch: 1, userunit: 1, userteam: 1, requestmode: 1
    //   });
    //   manuallimited = await Manualstock.find({
    //     handover: "handover", productname: req.body.productname, company: req.body.company, branch: req.body.branch, unit: req.body.unit, floor: req.body.floor, area: req.body.area,
    //     location: req.body.location
    //   },
    //     {
    //       company: 1, branch: 1, unit: 1, floor: 1, area: 1, location: 1, productname: 1, countquantity: 1, employeenameto: 1,
    //       addedby: 1, usercompany: 1, userbranch: 1, userunit: 1, userteam: 1, requestmode: 1
    //     });

    const [stocklimited, manuallimited] = await Promise.all([
      Stock.aggregate([
        {
          $match: {
            handover: "handover",
            productname: req.body.productname,
            company: req.body.company,
            branch: req.body.branch,
            unit: req.body.unit,
            floor: req.body.floor,
            area: req.body.area,
            location: req.body.location
          }
        },
        {
          $project: {
            company: 1, branch: 1, unit: 1, floor: 1, area: 1, location: 1, productname: 1,
            countquantity: 1, employeenameto: 1, addedby: 1, usercompany: 1, userbranch: 1,
            userunit: 1, userteam: 1, requestmode: 1,
            status: { $literal: "Stock" } // Adding status field
          }
        }
      ]),
      Manualstock.aggregate([
        {
          $match: {
            handover: "handover",
            productname: req.body.productname,
            company: req.body.company,
            branch: req.body.branch,
            unit: req.body.unit,
            floor: req.body.floor,
            area: req.body.area,
            location: req.body.location
          }
        },
        {
          $project: {
            company: 1, branch: 1, unit: 1, floor: 1, area: 1, location: 1, productname: 1,
            countquantity: 1, employeenameto: 1, addedby: 1, usercompany: 1, userbranch: 1,
            userunit: 1, userteam: 1, requestmode: 1,
            status: { $literal: "Manual" } // Adding status field
          }
        }
      ])
    ]);

    stock = [...stocklimited, ...manuallimited];


  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!stock) {
    return next(new ErrorHandler("Stock not found!", 404));
  }
  return res.status(200).json({
    stock,
  });
});


exports.getAllStockPurchaseStockCount = catchAsyncErrors(async (req, res, next) => {
  let stock;
  try {

    stock = await Stock.find({
      handover: { $in: ["usagcount", "return"] }, employeenameto: req.body.username,
    },
      {
        company: 1, branch: 1, unit: 1, floor: 1, area: 1, location: 1, productname: 1,
        countquantity: 1, handover: 1
      });
    // console.log(stock.length, "stockcount")
  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!stock) {
    return next(new ErrorHandler("Stock not found!", 404));
  }
  return res.status(200).json({
    stock,
  });
});

exports.getAllStockPurchaseStockCountUsage = catchAsyncErrors(async (req, res, next) => {
  let stock;
  try {

    let query = {

    }

    stock = await Stock.find({
      handover: "usagecount",
      "addedby.name": req.body.username,
    },
      {
        company: 1, branch: 1, unit: 1, floor: 1, area: 1, location: 1, productname: 1,
        countquantity: 1, handover: 1
      });
    // console.log(req.body.username, stock.length, "stockcoun112t")
  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!stock) {
    return next(new ErrorHandler("Stock not found!", 404));
  }
  return res.status(200).json({
    stock,
  });
});

exports.getAllStockPurchaseLimitedHandoverTodoReturn = catchAsyncErrors(async (req, res, next) => {
  let stock = [];
  try {

    // stocklimited = await Stock.find({
    //   handover: "return", productname: req.body.productname, company: req.body.company, branch: req.body.branch, unit: req.body.unit, floor: req.body.floor, area: req.body.area,
    //   location: req.body.location
    // },
    //   {
    //     company: 1, branch: 1, unit: 1, floor: 1, area: 1, location: 1, productname: 1,
    //     countquantity: 1, employeenameto: 1, addedby: 1, usercompany: 1, userbranch: 1, userunit: 1, userteam: 1, requestmode: 1
    //   });
    //   manuallimited = await Manualstock.find({
    //     handover: "return", productname: req.body.productname, company: req.body.company, branch: req.body.branch, unit: req.body.unit, floor: req.body.floor, area: req.body.area,
    //     location: req.body.location
    //   },
    //     {
    //       company: 1, branch: 1, unit: 1, floor: 1, area: 1, location: 1, productname: 1,
    //       countquantity: 1, employeenameto: 1, addedby: 1, usercompany: 1, userbranch: 1, userunit: 1, userteam: 1, requestmode: 1
    //     });

    const [stocklimited, manuallimited] = await Promise.all([
      Stock.aggregate([
        {
          $match: {
            handover: "return",
            productname: req.body.productname,
            company: req.body.company,
            branch: req.body.branch,
            unit: req.body.unit,
            floor: req.body.floor,
            area: req.body.area,
            location: req.body.location
          }
        },
        {
          $project: {
            company: 1, branch: 1, unit: 1, floor: 1, area: 1, location: 1, productname: 1,
            countquantity: 1, employeenameto: 1, addedby: 1, usercompany: 1, userbranch: 1,
            userunit: 1, userteam: 1, requestmode: 1,
            status: { $literal: "Stock" } // Adding status field
          }
        }
      ]),
      Manualstock.aggregate([
        {
          $match: {
            handover: "return",
            productname: req.body.productname,
            company: req.body.company,
            branch: req.body.branch,
            unit: req.body.unit,
            floor: req.body.floor,
            area: req.body.area,
            location: req.body.location
          }
        },
        {
          $project: {
            company: 1, branch: 1, unit: 1, floor: 1, area: 1, location: 1, productname: 1,
            countquantity: 1, employeenameto: 1, addedby: 1, usercompany: 1, userbranch: 1,
            userunit: 1, userteam: 1, requestmode: 1,
            status: { $literal: "Manual" } // Adding status field
          }
        }
      ])
    ]);

    stock = [...stocklimited, ...manuallimited];

  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!stock) {
    return next(new ErrorHandler("Stock not found!", 404));
  }
  return res.status(200).json({
    stock,
  });
});

//nofification return

exports.getAllStockPurchaseLimitedHandoverTodoNotification = catchAsyncErrors(async (req, res, next) => {
  let stock;
  try {

    stock = await Stock.find({
      handover: "handover", productname: req.body.productname, branch: req.body.branch, unit: req.body.unit, floor: req.body.floor, area: req.body.area,
      location: req.body.location, employeenameto: req.body.employeenameto
    },
      {
        company: 1, branch: 1, unit: 1, floor: 1, area: 1, location: 1, productname: 1, countquantity: 1, employeenameto: 1,
        addedby: 1, usercompany: 1, userbranch: 1, userunit: 1, userteam: 1, requestmode: 1
      });

  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!stock) {
    return next(new ErrorHandler("Stock not found!", 404));
  }
  return res.status(200).json({
    stock,
  });
});


exports.getAllStockPurchaseLimitedHandoverTodoReturnNotification = catchAsyncErrors(async (req, res, next) => {
  let stock;
  try {

    stock = await Stock.find({
      handover: "return", productname: req.body.productname, branch: req.body.branch, unit: req.body.unit, floor: req.body.floor, area: req.body.area,
      location: req.body.location, employeenameto: req.body.employeenameto
    },
      {
        company: 1, branch: 1, unit: 1, floor: 1, area: 1, location: 1, productname: 1, countquantity: 1, employeenameto: 1,
        addedby: 1, usercompany: 1, userbranch: 1, userunit: 1, userteam: 1, requestmode: 1
      });

  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!stock) {
    return next(new ErrorHandler("Stock not found!", 404));
  }
  return res.status(200).json({
    stock,
  });
});



exports.getAllStockPurchaseLimitedHandoverandReturn = catchAsyncErrors(async (req, res, next) => {
  let stock;
  try {

    stock = await Stock.find({
      handover: { $in: ["handover", "return"] }, productname: req.body.productname, branch: req.body.branch, unit: req.body.unit, floor: req.body.floor, area: req.body.area,
      location: req.body.location
    },
      { company: 1, branch: 1, unit: 1, floor: 1, area: 1, location: 1, productname: 1, countquantity: 1, employeenameto: 1, addedby: 1, handover: 1 });
    // console.log(stock, "astosdfljrwlj")
  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!stock) {
    return next(new ErrorHandler("Stock not found!", 404));
  }
  return res.status(200).json({
    stock,
  });
});




exports.getOverallStockTableSort = catchAsyncErrors(async (req, res, next) => {
  const { page, pageSize, searchQuery } = req.body;

  let allusers;
  let totalProjects, paginatedData, isEmptyData, result;

  try {
    // const query = searchQuery ? { companyname: { $regex: searchQuery, $options: 'i' } } : {};
    const anse = await Stock.find()
    const searchOverTerms = searchQuery?.toLowerCase()?.split(" ");
    const filteredDatas = anse?.filter((item, index) => {
      const itemString = JSON.stringify(item)?.toLowerCase();
      return searchOverTerms.every((term) => itemString.includes(term));
    })
    isEmptyData = searchOverTerms?.every(item => item.trim() === '');
    const pageSized = parseInt(pageSize);
    const pageNumberd = parseInt(page);

    paginatedData = filteredDatas.slice((pageNumberd - 1) * pageSized, pageNumberd * pageSize);

    totalProjects = await Stock.countDocuments();

    allusers = await Stock.find()
      .skip((page - 1) * pageSize)
      .limit(parseInt(pageSize));

    result = isEmptyData ? allusers : paginatedData

  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  // return res.status(200).json({ count: allusers.length, allusers });
  return res.status(200).json({
    allusers,
    totalProjects,
    paginatedData,
    result,
    currentPage: (isEmptyData ? page : 1),
    totalPages: Math.ceil((isEmptyData ? totalProjects : paginatedData?.length) / pageSize),
  });
});



exports.getAllStockManagementViewDate = catchAsyncErrors(async (req, res, next) => {
  let stock;
  try {

    const { company, branch, unit, floor, area, location, productname, quantity, requestmode, status } = req.body;

    let query = {



      company: company,
      branch: branch,
      unit: unit,
      floor: floor,
      area: area,
      location: location,
      productname: productname,
      requestmode: requestmode,
      handover: { $exists: false }
    }
    // console.log(query, "qu")
    if (status == "Stock") {
      stock = await Stock.find(query, { company: 1, branch: 1, unit: 1, floor: 1, area: 1, location: 1, productname: 1, requestmode: 1, quantity: 1, addedby: 1 });
    } else {
      stock = await Manualstock.find(query, { company: 1, branch: 1, unit: 1, floor: 1, area: 1, location: 1, productname: 1, requestmode: 1, quantity: 1, addedby: 1 });

    }
  } catch (err) {
    console.log(err, "errecv")
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!stock) {

    return next(new ErrorHandler("Stock not found!", 404));
  }
  return res.status(200).json({
    stock,
  });
});

exports.getAllStockManagementViewDateStockMaterial = catchAsyncErrors(async (req, res, next) => {
  let stocklimited, manuallimited, stock = [];
  try {

    const { company, branch, unit, floor, area, location, productname, quantity, requestmode, status } = req.body;

    let query = {



      company: company,
      branch: branch,
      unit: unit,
      floor: floor,
      area: area,
      location: location,
      "stockmaterialarray.materialnew": productname,
      requestmode: requestmode,
      handover: { $exists: false }
    }
    // console.log(query, "qu")
    if (status == "Stock") {
      stock = await Stock.find(query, {
        company: 1, branch: 1, unit: 1, floor: 1, area: 1, location: 1, productname: 1, requestmode: 1, quantity: 1,
        addedby: 1, stockmaterialarray: 1
      });
    } else {
      stock = await Manualstock.find(query, {
        company: 1, branch: 1, unit: 1, floor: 1, area: 1, location: 1, productname: 1, requestmode: 1, quantity: 1,
        addedby: 1, stockmaterialarray: 1
      });
    }

    // console.log(stock, "stock")
  } catch (err) {
    // console.log(err, "errecv")
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!stock) {

    return next(new ErrorHandler("Stock not found!", 404));
  }
  return res.status(200).json({
    stock,
  });
});


exports.getAllStockManagementViewDateIndividual = catchAsyncErrors(async (req, res, next) => {
  let stock;
  try {

    const { company, branch, unit, productname, requestmode } = req.body;

    let query = {



      // usercompany: company,
      // userbranch: branch,
      // userunit: unit,
      productname: productname,
      requestmode: requestmode,
      handover: "return"
    }
    // console.log(query, "qu")
    stock = await Stock.find(query, {
      company: 1, branch: 1, unit: 1, floor: 1, area: 1, location: 1, productname: 1, usercompany: 1, userbranch: 1, userunit: 1,
      userfloor: 1, userarea: 1, userlocation: 1, useremployee: 1, userteam: 1, countquantity: 1,
      requestmode: 1, quantity: 1, addedby: 1
    });
    // console.log(stock, "stock")
  } catch (err) {
    console.log(err, "errecv")
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!stock) {

    return next(new ErrorHandler("Stock not found!", 404));
  }
  return res.status(200).json({
    stock,
  });
});


exports.getAllStockManagementViewDateStockMaterialIndividual = catchAsyncErrors(async (req, res, next) => {
  let stock;
  try {

    const { company, branch, unit, floor, area, location, productname, quantity, requestmode } = req.body;

    let query = {



      company: company,
      branch: branch,
      unit: unit,
      floor: floor,
      area: area,
      location: location,
      "stockmaterialarray.materialnew": productname,
      requestmode: requestmode,
      handover: "return"
    }
    // console.log(query, "qu")
    stock = await Stock.find(query, {
      company: 1, branch: 1, unit: 1, floor: 1, area: 1, location: 1, productname: 1, usercompany: 1, userbranch: 1, userunit: 1,
      userfloor: 1, userarea: 1, userlocation: 1, useremployee: 1, userteam: 1,
      requestmode: 1, quantity: 1, addedby: 1
    });
    // console.log(stock, "stock")
  } catch (err) {
    console.log(err, "errecv")
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!stock) {

    return next(new ErrorHandler("Stock not found!", 404));
  }
  return res.status(200).json({
    stock,
  });
});



exports.getAllStockPurchaseLimitedOverallReport = catchAsyncErrors(async (req, res, next) => {
  let stock;
  try {

    stock = await Stock.find({
      requestmode: req.body.assetmat, company: req.body.companyto,
      branch: { $in: req.body.branchto }, unit: { $in: req.body.unitto }, handover: { $in: req.body.status }

    },

      {
        requestmode: 1, company: 1, branch: 1, unit: 1,
        usercompany: 1, userbranch: 1, userunit: 1, userfloor: 1, userarea: 1, userlocation: 1, userteam: 1,
        floor: 1, area: 1, location: 1, productname: 1, quantity: 1, stockmaterialarray: 1, countquantity: 1, employeenameto: 1, handover: 1, addedby: 1
      });
    // console.log(stock, "stockelskfj")
    // console.log(req.body.status, "Status")
  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!stock) {
    return next(new ErrorHandler("Stock not found!", 404));
  }
  return res.status(200).json({
    stock,
  });
});


exports.getAllStockExcelDownloadStock = catchAsyncErrors(async (req, res, next) => {
  let stock;
  try {
    stock = await Stock.find({}, {
      company: 1,
      branch: 1,
      unit: 1,
      floor: 1,
      area: 1,
      location: 1,
      requestmode: 1,
      stockcategory: 1,
      stocksubcategory: 1,
      quantitynew: 1,
      uomnew: 1,
      materialnew: 1,
      productdetailsnew: 1,
      gstno: 1,
      billno: 1,
      warrantydetails: 1,
      warranty: 1,
      purchasedate: 1,
      billdate: 1,
      rate: 1,
      vendorgroup: 1,
      vendor: 1,
      stockmaterialarray: 1,
      quantitynew: 1
    });
  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!stock) {
    return next(new ErrorHandler("Stock not found!", 404));
  }
  return res.status(200).json({
    stock,
  });
});


const capitalizeHeader = (str) => {
  return str
    .replace(/_/g, " ") // Replace underscores with spaces
    .replace(/\b\w/g, (char) => char.toUpperCase()); // Capitalize each word
};

// exports.getAllStockExcelDownloadAsset = catchAsyncErrors(async (req, res, next) => {
//   let stock;

//   try {
//     const workbook = new ExcelJS.Workbook();
//     const worksheet = workbook.addWorksheet("Data");

//     // Fetch the first document to define headers
//     const firstDoc = await Stock.findOne({}, {
//       company: 1,
//       branch: 1,
//       unit: 1,
//       floor: 1,
//       area: 1,
//       location: 1,
//       requestmode: 1,
//       stockcategory: 1,
//       stocksubcategory: 1,
//       quantitynew: 1,
//       uomnew: 1,
//       materialnew: 1,
//       productdetailsnew: 1,
//       gstno: 1,
//       billno: 1,
//       warrantydetails: 1,
//       warranty: 1,
//       purchasedate: 1,
//       billdate: 1,
//       rate: 1,
//       vendorgroup: 1,
//       vendor: 1,
//       stockmaterialarray: 1,
//       quantitynew: 1
//     }).lean();
//     if (!firstDoc) return res.status(404).send("No data found");

//     // Define headers dynamically
//     const headers = Object.keys(firstDoc).map((key) => ({
//       header: capitalizeHeader(key), // Capitalized Header
//       key,
//     }));
//     worksheet.columns = headers;

//     // Set response headers to stream the file
//     res.setHeader("Content-Disposition", "attachment; filename=data.xlsx");
//     res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");

//     // Create a stream
//     const stream = new PassThrough();
//     workbook.xlsx.write(stream).then(() => stream.end());

//     // Pipe the stream to response
//     stream.pipe(res);

//     // Stream data from MongoDB and write rows to Excel
//     const dataStream = Stock.find({}, {
//       company: 1,
//       branch: 1,
//       unit: 1,
//       floor: 1,
//       area: 1,
//       location: 1,
//       requestmode: 1,
//       stockcategory: 1,
//       stocksubcategory: 1,
//       quantitynew: 1,
//       uomnew: 1,
//       materialnew: 1,
//       productdetailsnew: 1,
//       gstno: 1,
//       billno: 1,
//       warrantydetails: 1,
//       warranty: 1,
//       purchasedate: 1,
//       billdate: 1,
//       rate: 1,
//       vendorgroup: 1,
//       vendor: 1,
//       stockmaterialarray: 1,
//       quantitynew: 1
//     }).cursor();
//     for await (let doc of dataStream) {
//       worksheet.addRow(doc);
//     }

//     await workbook.xlsx.write(res);
//   }
//   catch (err) {
//     console.log(err, "err")
//     return next(new ErrorHandler("Records not found!", 404));
//   }
//   if (!stock) {
//     return next(new ErrorHandler("Stock not found!", 404));
//   }
//   return res.status(200).json(
//     "download successfully",
//   );
// });



// Route to Export Large MongoDB Data to Excel


// exports.getAllStockExcelDownloadAsset = async (req, res, next) => {
//   try {
//     const workbook = new ExcelJS.stream.xlsx.WorkbookWriter({ stream: new PassThrough() });
//     const worksheet = workbook.addWorksheet("Stock Data");

//     // Define Headers Dynamically
//     const firstDoc = await Stock.findOne({ requestmode: req.body.mode }).lean();
//     if (!firstDoc) return res.status(404).send("No data found");

//     const headers = Object.keys(firstDoc).map((key) => ({
//       header: key.charAt(0).toUpperCase() + key.slice(1), // Capitalized Header
//       key,
//     }));
//     worksheet.columns = headers;

//     // Set Response Headers for Streaming
//     res.setHeader("Content-Disposition", "attachment; filename=stock_data.xlsx");
//     res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");

//     // Create a Stream and Pipe It to Response
//     const stream = new PassThrough();
//     workbook.stream.pipe(res);

//     // MongoDB Cursor for Streaming Large Data Efficiently
//     const dataStream = Stock.find({ requestmode: req.body.mode })
//       .select(headers.map(h => h.key).join(" ")) // Fetch only necessary fields
//       .lean()
//       .cursor();

//     for await (let doc of dataStream) {
//       worksheet.addRow(doc).commit(); // Write each row to stream directly
//     }

//     await workbook.commit(); // Finish writing and flush the stream
//     stream.end();

//   } catch (err) {
//     console.error("Export error:", err);
//     return next(new ErrorHandler("Error exporting data", 500));
//   }
// };

// exports.getAllStockExcelDownloadAsset = async (req, res, next) => {
//   try {
//     const workbook = new ExcelJS.Workbook();
//     const worksheet = workbook.addWorksheet("Stock Data");

//     // Set response headers to stream the file
//     res.setHeader("Content-Disposition", "attachment; filename=stock_data.xlsx");
//     res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");

//     // Aggregation pipeline to stream data directly
//     const dataStream = Stock.aggregate([
//       {
//         $match: { requestmode: req.body.mode }, // Filter based on mode or other parameters
//       },
//       {
//         $project: { // Only include the required fields
//           company: 1,
//           branch: 1,
//           unit: 1,
//           floor: 1,
//           area: 1,
//           location: 1,
//           requestmode: 1,
//           vendorgroup: 1,
//           vendor: 1,
//           gstno: 1,
//           billno: 1,
//           assettype: 1,
//           producthead: 1,
//           productname: 1,
//           warranty: 1,
//           purchasedate: 1,
//           productdetails: 1,
//           warrantydetails: 1,
//           quantity: 1,
//           uom: 1,
//           rate: 1,
//           billdate: 1
//         }
//       },
//     ]).cursor(); // MongoDB cursor for streaming data

//     // Stream data to Excel row by row
//     for await (let doc of dataStream) {
//       worksheet.addRow(doc); // Add each document as a row
//     }

//     // After all data has been written, send the Excel file to client
//     await workbook.xlsx.write(res); // Directly write Excel to response stream
//     res.end(); // End the response after data is written

//   } catch (err) {
//     console.error("Export error:", err);
//     return next(new ErrorHandler("Error exporting data", 500));
//   }
// };


exports.getAllStockExcelDownloadAsset = async (req, res, next) => {
  try {
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet("Stock Data");

    // Set response headers to stream the file
    res.setHeader("Content-Disposition", "attachment; filename=stock_data.xlsx");
    res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");

    // Aggregation pipeline to stream data directly from MongoDB
    // console.log(req.body.mode, "mode")
    const dataStream = Stock.aggregate([
      { $match: { requestmode: req.body.mode } },
      {
        $project: {
          company: 1,
          branch: 1,
          unit: 1,
          floor: 1,
          area: 1,
          location: 1,
          requestmode: 1,
          vendorgroup: 1,
          vendor: 1,
          gstno: 1,
          billno: 1,
          assettype: 1,
          producthead: 1,
          productname: 1,
          warranty: 1,
          purchasedate: 1,
          productdetails: 1,
          warrantydetails: 1,
          quantity: 1,
          uom: 1,
          rate: 1,
          billdate: 1
        }
      }
    ]).cursor();

    // Add headers dynamically if you want
    const headers = [
      { header: 'Company', key: 'company' },
      { header: 'Branch', key: 'branch' },
      { header: 'Unit', key: 'unit' },
      { header: 'Floor', key: 'floor' },
      { header: 'Area', key: 'area' },
      { header: 'Location', key: 'location' },
      { header: 'Request Mode', key: 'requestmode' },
      { header: 'Vendor Group', key: 'vendorgroup' },
      { header: 'Vendor', key: 'vendor' },
      { header: 'GST No', key: 'gstno' },
      { header: 'Bill No', key: 'billno' },
      { header: 'Asset Type', key: 'assettype' },
      { header: 'Product Head', key: 'producthead' },
      { header: 'Product Name', key: 'productname' },
      { header: 'Warranty', key: 'warranty' },
      { header: 'Purchase Date', key: 'purchasedate' },
      { header: 'Product Details', key: 'productdetails' },
      { header: 'Warranty Details', key: 'warrantydetails' },
      { header: 'Quantity', key: 'quantity' },
      { header: 'UOM', key: 'uom' },
      { header: 'Rate', key: 'rate' },
      { header: 'Bill Date', key: 'billdate' }
    ];

    worksheet.columns = headers;

    // Stream data to Excel row by row
    for await (let doc of dataStream) {
      // console.log(doc, "doc")
      worksheet.addRow(doc); // Add each document as a row in Excel
    }

    // Once all data is streamed, write the workbook to the response
    await workbook.xlsx.write(res);
    res.end(); // End the response to finalize the download

  } catch (err) {
    console.error("Export error:", err);
    return next(new ErrorHandler("Error exporting data", 500));
  }
};




exports.getAllStockPdfDownloadAssetPDF = async (req, res, next) => {
  try {
    // Create a new PDF document
    const doc = new PDFDocument();

    // Set response headers to stream the PDF file
    res.setHeader("Content-Disposition", "attachment; filename=stock_data.pdf");
    res.setHeader("Content-Type", "application/pdf");

    // Pipe the document to the response object
    doc.pipe(res);

    // Fetch data from MongoDB
    const dataStream = Stock.aggregate([
      { $match: { requestmode: req.body.mode } },
      {
        $project: {
          company: 1,
          branch: 1,
          unit: 1,
          floor: 1,
          area: 1,
          location: 1,
          requestmode: 1,
          vendorgroup: 1,
          vendor: 1,
          gstno: 1,
          billno: 1,
          assettype: 1,
          producthead: 1,
          productname: 1,
          warranty: 1,
          purchasedate: 1,
          productdetails: 1,
          warrantydetails: 1,
          quantity: 1,
          uom: 1,
          rate: 1,
          billdate: 1
        }
      }
    ]).cursor();

    // Add title or header to the PDF document
    doc.fontSize(18).text('Stock Data Report', { align: 'center' });
    doc.moveDown();

    // Add table headers
    const headers = [
      'Company', 'Branch', 'Unit', 'Floor', 'Area', 'Location', 'Request Mode',
      'Vendor Group', 'Vendor', 'GST No', 'Bill No', 'Asset Type', 'Product Head',
      'Product Name', 'Warranty', 'Purchase Date', 'Product Details', 'Warranty Details',
      'Quantity', 'UOM', 'Rate', 'Bill Date'
    ];

    doc.fontSize(12).text(headers.join(' | '), { align: 'center' });
    doc.moveDown();

    // Add data rows to the PDF
    for await (let docData of dataStream) {
      const row = [
        docData.company, docData.branch, docData.unit, docData.floor, docData.area,
        docData.location, docData.requestmode, docData.vendorgroup, docData.vendor,
        docData.gstno, docData.billno, docData.assettype, docData.producthead,
        docData.productname, docData.warranty, docData.purchasedate, docData.productdetails,
        docData.warrantydetails, docData.quantity, docData.uom, docData.rate, docData.billdate
      ];
      doc.text(row.join(' | '), { align: 'center' });
    }

    // Finalize the PDF document
    doc.end();
  } catch (err) {
    console.error("Export error:", err);
    return next(new ErrorHandler("Error exporting data", 500));
  }
};









