
const SalarySlab = require("../../../model/modules/setup/SalarySlabModel");
const ErrorHandler = require("../../../utils/errorhandler");
const catchAsyncErrors = require("../../../middleware/catchAsyncError");

// get All SalarySlab => /api/salaryslabs
exports.getAllSalarySlab = catchAsyncErrors(async (req, res, next) => {
  let salaryslab;
  try {
    salaryslab = await SalarySlab.find();
  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!salaryslab) {
    return next(new ErrorHandler("Data not found!", 404));
  }
  return res.status(200).json({
    // count: products.length,
    salaryslab,
  });
});

// get All SalarySlab => /api/salaryslabs
exports.getsalarySlabProcessFilter = catchAsyncErrors(async (req, res, next) => {
  let salaryslab, uniqueSalarySlab;
  try {
    salaryslab = await SalarySlab.find({ processqueue: req.body.process }, { salarycode: 1, processqueue: 1 });
    // uniqueSalarySlab = Array.from(new Set(salaryslab.map(item => item.salarycode)));

  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!salaryslab) {
    return next(new ErrorHandler("Data not found!", 404));
  }
  return res.status(200).json({
    // count: products.length,
    salaryslab,
  });
});

// get All SalarySlab => /api/salaryslabs
exports.salarySlabFilter = catchAsyncErrors(async (req, res, next) => {
  let salaryslab;
  try {

    salaryslab = await SalarySlab.find({}, {
      company: 1, branch: 1, salarycode: 1, basic: 1, hra: 1, salaryslablimited: 1,
      medicalallowance: 1, conveyance: 1, productionallowance: 1, productionallowancetwo: 1, otherallowance: 1, esipercentage: 1, esimaxsalary: 1,
      pfpercentage: 1, pfemployeepercentage: 1, esiemployeepercentage: 1

    });

  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!salaryslab) {
    return next(new ErrorHandler("Data not found!", 404));
  }
  return res.status(200).json({
    // count: products.length,
    salaryslab,
  });
});


// Create new SalarySlab=> /api/salaryslab/new
exports.addSalarySlab = catchAsyncErrors(async (req, res, next) => {

  let asalaryslab = await SalarySlab.create(req.body);

  return res.status(200).json({
    message: "Successfully added!",
  });
});

// get Signle SalarySlab => /api/salaryslab/:id
exports.getSingleSalarySlab = catchAsyncErrors(async (req, res, next) => {
  const id = req.params.id;

  let ssalaryslab = await SalarySlab.findById(id);

  if (!ssalaryslab) {
    return next(new ErrorHandler("Data not found!", 404));
  }
  return res.status(200).json({
    ssalaryslab,
  });
});

// update SalarySlab by id => /api/salaryslab/:id
exports.updateSalarySlab = catchAsyncErrors(async (req, res, next) => {
  const id = req.params.id;
  let usalaryslab = await SalarySlab.findByIdAndUpdate(id, req.body);
  if (!usalaryslab) {
    return next(new ErrorHandler("Data not found!", 404));
  }
  return res.status(200).json({ message: "Updated successfully" });
});

// delete SalarySlab by id => /api/salaryslab/:id
exports.deleteSalarySlab = catchAsyncErrors(async (req, res, next) => {
  const id = req.params.id;

  let dsalaryslab = await SalarySlab.findByIdAndRemove(id);

  if (!dsalaryslab) {
    return next(new ErrorHandler("Data not found!", 404));
  }
  return res.status(200).json({ message: "Deleted successfully" });
});


exports.getsalarySlabProcessFilterSort = catchAsyncErrors(async (req, res, next) => {
  let totalProjects, result, totalPages, currentPage;

  const { frequency, page, pageSize } = req.body;
  try {

    totalProjects = await SalarySlab.countDocuments();


    result = await SalarySlab.find()
      .skip((page - 1) * pageSize)
      .limit(parseInt(pageSize));


  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }

  return res.status(200).json({
    totalProjects,
    result,
    currentPage: page,
    totalPages: Math.ceil(totalProjects / pageSize),
  });
});


exports.getAllSalarySlabListFilter = catchAsyncErrors(async (req, res, next) => {
  let salaryslab;
  try {

    const { company, branch, process } = req.body;
    let query = {};

    if (company && company.length > 0) {
      query.company = { $in: company };
    }

    if (branch && branch.length > 0) {
      query.branch = { $in: branch };
    }

    if (process && process.length > 0) {
      query.processqueue = { $in: process };
    }



    salaryslab = await SalarySlab.find(query);

    return res.status(200).json({
      salaryslab,
    });
  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
});

exports.salarySlabFilterAssignbranch = catchAsyncErrors(async (req, res, next) => {
  const { assignbranch } = req.body;



  const query = {}
  if (assignbranch.length > 0) {
    query.$or = assignbranch.map(item => ({
      company: item.company,
      branch: item.branch,
    }))
  };

  let salaryslab;
  try {

    salaryslab = await SalarySlab.find(query, {
      company: 1, branch: 1, salarycode: 1, basic: 1, hra: 1, salaryslablimited: 1,
      medicalallowance: 1, conveyance: 1, productionallowance: 1, productionallowancetwo: 1, otherallowance: 1, esipercentage: 1, esimaxsalary: 1,
      pfpercentage: 1, pfemployeepercentage: 1, esiemployeepercentage: 1

    });

  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!salaryslab) {
    return next(new ErrorHandler("Data not found!", 404));
  }
  return res.status(200).json({
    // count: products.length,
    salaryslab,
  });
});


exports.getsalarySlabProcessFilterSortByAssignBranch = catchAsyncErrors(async (req, res, next) => {
  let totalProjects, result, totalPages, currentPage;

  const { frequency, page, pageSize, assignbranch } = req.body;

  const query = {
    $or: assignbranch.map(item => ({
      company: item.company,
      branch: item.branch,
    }))
  };
  try {

    totalProjects = await SalarySlab.countDocuments(query);


    result = await SalarySlab.find(query)
      .skip((page - 1) * pageSize)
      .limit(parseInt(pageSize));


  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }

  return res.status(200).json({
    totalProjects,
    result,
    currentPage: page,
    totalPages: Math.ceil(totalProjects / pageSize),
  });
});




exports.salarySlabFilterAssignbranchHome = catchAsyncErrors(async (req, res, next) => {

  let salaryslab;
  try {

    salaryslab = await SalarySlab.find({ salarycode: { $in: req.body.processcode } }, {
      company: 1, branch: 1, salarycode: 1, basic: 1, hra: 1, salaryslablimited: 1,
      medicalallowance: 1, conveyance: 1, productionallowance: 1, productionallowancetwo: 1, otherallowance: 1, esipercentage: 1, esimaxsalary: 1,
      pfpercentage: 1, pfemployeepercentage: 1, esiemployeepercentage: 1

    });

  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!salaryslab) {
    return next(new ErrorHandler("Data not found!", 404));
  }
  return res.status(200).json({
    // count: products.length,
    salaryslab,
  });
});