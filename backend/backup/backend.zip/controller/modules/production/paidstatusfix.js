const Paidstatusfix = require("../../../model/modules/production/paidstatusfix");
const ErrorHandler = require("../../../utils/errorhandler");
const catchAsyncErrors = require("../../../middleware/catchAsyncError");
const PayrunList = require("../../../model/modules/production/payrunlist");

// get All Paidstatusfix => /api/processteams
exports.getAllPaidstatusfix = catchAsyncErrors(async (req, res, next) => {
  let paidstatusfixs;
  try {
    paidstatusfixs = await Paidstatusfix.find();
  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!paidstatusfixs) {
    return next(new ErrorHandler("Paidstatusfix not found!", 404));
  }
  return res.status(200).json({
    // count: products.length,
    paidstatusfixs,
  });
});

exports.xeroxPaidStatusFixFilter = catchAsyncErrors(async (req, res, next) => {
  let statusresults;
  try {
    statusresults = await Paidstatusfix.find({
      month: { $regex: new RegExp(req.body.frommonth, 'i') }, // 'i' flag for case-insensitivity
      year: { $regex: new RegExp(req.body.fromyear, 'i') }    // 'i' flag for case-insensitivity
    }, {});
  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!statusresults) {
    return next(new ErrorHandler("Data not found!", 404));
  }
  return res.status(200).json({
    statusresults,
  });
});

// get Limited Paidstatusfix => /api/processteams
exports.getPaidstatusfixLimited = catchAsyncErrors(async (req, res, next) => {
  let paidstatusfixs;
  try {
    const reqMonth = req.body.month.toLowerCase(); // Convert req.body.month to lowercase
    const reqYear = req.body.year;

    paidstatusfixs = await Paidstatusfix.find(
      { month: { $regex: new RegExp('^' + reqMonth, 'i') }, year: reqYear },
       {department:1, month:1, year:1, frequency:1,absentmodes:1,fromvalue:1,tovalue:1,
      achievedmodes:1, frompoint:1, topoint:1, currentabsentmodes:1, currentabsentvalue:1, currentachievedmodes:1, currentachievedvalue:1, paidstatus:1
       });
  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!paidstatusfixs) {
    return next(new ErrorHandler("Paidstatusfix not found!", 404));
  }
  return res.status(200).json({
    // count: products.length,
    paidstatusfixs,
  });
});

// Create new Paidstatusfix => /api/Paidstatusfix/new
exports.addPaidstatusfix = catchAsyncErrors(async (req, res, next) => {
  let aPaidstatusfix = await Paidstatusfix.create(req.body);

  return res.status(200).json({
    message: "Successfully added!",
  }); 
});

// get Signle Paidstatusfix => /api/Paidstatusfix/:id
exports.getSinglePaidstatusfix = catchAsyncErrors(async (req, res, next) => {
  const id = req.params.id;

  let spaidstatusfix = await Paidstatusfix.findById(id);

  if (!spaidstatusfix) {
    return next(new ErrorHandler("Paidstatusfix not found!", 404));
  }
  return res.status(200).json({
    spaidstatusfix,
  });
});

// update Paidstatusfix by id => /api/Paidstatusfix/:id
exports.updatePaidstatusfix = catchAsyncErrors(async (req, res, next) => {
  const id = req.params.id;
  let upaidstatusfix = await Paidstatusfix.findByIdAndUpdate(id, req.body);
  if (!upaidstatusfix) {
    return next(new ErrorHandler("Paidstatusfix not found!", 404));
  }
  return res.status(200).json({ message: "Updated successfully" });
});

// delete Paidstatusfix by id => /api/Paidstatusfix/:id
exports.deletePaidstatusfix = catchAsyncErrors(async (req, res, next) => {
  const id = req.params.id;

  let dpaidstatusfix = await Paidstatusfix.findByIdAndRemove(id);

  if (!dpaidstatusfix) {
    return next(new ErrorHandler("Paidstatusfix not found!", 404));
  }
  return res.status(200).json({ message: "Deleted successfully" });
});

exports.PaidstatusfixSort = catchAsyncErrors(async (req, res, next) => {
  let totalProjects, result, totalPages, currentPage;

  const { page, pageSize } = req.body;
  try {

      totalProjects = await Paidstatusfix.countDocuments();

      result = await Paidstatusfix.find()
          .skip((page - 1) * pageSize)
          .limit(parseInt(pageSize));

  } catch (err) {
      return next(new ErrorHandler("Records not found!", 404));
  }

  return res.status(200).json({
      totalProjects,
      result,
      currentPage: page,
      totalPages: Math.ceil(totalProjects / pageSize),
  });
});

// get All Paidstatusfix => /api/processteams
exports.getAllPaidstatusfixFiltered = catchAsyncErrors(async (req, res, next) => {
  let paidstatusfixs;
  try {
    const reqMonth = req.body.month.toLowerCase();
    const query = {
      month: { $regex: new RegExp("^" + reqMonth, "i") },
      year: req.body.year,
      paidstatus: { $regex: "MANUAL" },
    };

    paidstatusfixs = await Paidstatusfix.find(query, { paidstatus: 1, _id: 0, department: 1 });
  } catch (err) {
    console.log(err.message);
  }
  // if (!paidstatusfixs) {
  //   return next(new ErrorHandler("Paidstatusfix not found!", 404));
  // }
  return res.status(200).json({

    paidstatusfixs,
  });
});


// get All Filter Paid statsus Details => /api/queue

//working controller filter wise 

// exports.getAllFilterPaidStatusfixDatas = async (req, res) => {
//   try {
//     const { monthfilter, yearfilter, paidstatusfilter } = req.body;
//     console.log(req.body)
//     const filterQuery = {}; 

//     if (monthfilter && monthfilter.length > 0) {
//       filterQuery.month = { $in: monthfilter };
//     }
//     if (yearfilter && yearfilter.length > 0) {
//       filterQuery.year = { $in: yearfilter };
//     }
//     if (paidstatusfilter && paidstatusfilter.length > 0) {
//       filterQuery.paidstatus = { $in: paidstatusfilter };
//     }

//     console.log(filterQuery, 'filterQuery');

//     const filteredUsers = await Paidstatusfix.find(filterQuery);
//     console.log(filteredUsers, 'filteredUsers');
    
    
//     return res.status(200).json({ paidstatusfixs: filteredUsers });
    
//   } catch (err) {
//     console.error(err);
//     return res.status(500).json({ error: "Internal server error" });
//   }
// };


// get all pagination controller filterwise
exports.getAllFilterPaidStatusfixDatas = async (req, res, next) => {
  try {
    const { monthfilter, yearfilter, frequencystatusfilter, page , pageSize } = req.body; 
    const filterQuery = {};

    if (monthfilter && monthfilter.length > 0) {
      filterQuery.month = { $in: monthfilter };
    }
    if (yearfilter && yearfilter.length > 0) {
      filterQuery.year = { $in: yearfilter };
    }
    if (frequencystatusfilter && frequencystatusfilter.length > 0) {
      filterQuery.frequency = { $in: frequencystatusfilter };
    }

    const isEmpty = (obj) => {
      return Object.keys(obj).length === 0;
    };

    const totalProjects = !isEmpty(filterQuery) ? await Paidstatusfix.countDocuments(filterQuery) : 0;

    const result = isEmpty(filterQuery) ? [] : await Paidstatusfix.find(filterQuery)
      .skip((page - 1) * pageSize)  
      .limit(parseInt(pageSize));  

    const totalPages = isEmpty(filterQuery) ? 0 : Math.ceil(totalProjects / pageSize);

    return res.status(200).json({
      totalProjects,
      result,
      currentPage: page,
      totalPages,
    });

  } catch (err) {
    console.error(err);
    return next(new ErrorHandler("Internal server error", 500));
  }
};

// get overall delete functionlity  pay run
exports.getAllPayrunCheck = catchAsyncErrors(async (req, res, next) => {
  let payrunlists,count;

  try {

    payrunlists = await PayrunList.aggregate([
      {
        $match: {
          // department: req.body.checkpayrundepartment,
          "data.paidstatus" : req.body.checkpayrunpaidstatus
        }
      }
    ]);

    count = payrunlists.length

  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!payrunlists) {
    return next(new ErrorHandler("PayrunList not found!", 404));
  }
  return res.status(200).json({
    payrunlists,
    count
  });
});

    


// get All Paiddate fix  =>overall edit  payrun
exports.getOverAllEditPayrunList = catchAsyncErrors(async (req, res, next) => {
  let payrunlists;
  try {
 
    payrunlists = await PayrunList.aggregate([
      {
        $match: {
          department:  { $in: req.body.oldname2 },
          "data.paidstatus" : req.body.oldname
        }
      }
    ]);

  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }

  if (!payrunlists) {
    return next(new ErrorHandler("PayrunList not found", 404));
  }
  return res.status(200).json({
    count: payrunlists.length,
    payrunlists,
  });
});

