const ProductionConsolidated = require("../../../model/modules/production/productionConsolidated");
const DayPointsUpload = require("../../../model/modules/production/dayPointsUpload");
const ErrorHandler = require("../../../utils/errorhandler");
const catchAsyncErrors = require("../../../middleware/catchAsyncError");

// get All ProductionConsolidated Name => /api/productionconsolidateds
exports.getAllProductionConsolidated = catchAsyncErrors(async (req, res, next) => {
  let productionconsolidated;
  try {
    productionconsolidated = await ProductionConsolidated.find();
  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!productionconsolidated) {
    return next(new ErrorHandler("Production Consolidated  not found!", 404));
  }
  return res.status(200).json({
    // count: products.length,
    productionconsolidated,
  });
});


// get All ProductionConsolidated Name => /api/productionconsolidateds
exports.getFilterProductionConsolidated = catchAsyncErrors(async (req, res, next) => {
  let productionconsolidated , daypoints, ans ;
  try {
    productionconsolidated = await ProductionConsolidated.find({_id : req.body.id});
    daypoints = await DayPointsUpload.find();
    let answer = daypoints.map((data)=>  data.uploaddata).flat();
  ans = answer.filter(data=> data.date >= productionconsolidated[0].fromdate && data.date <= productionconsolidated[0].todate)
  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  return res.status(200).json({
    // count: products.length,
    productionconsolidated,ans
  });
});
// Create new ProductionConsolidated=> /api/productionconsolidated/new
exports.addProductionConsolidated = catchAsyncErrors(async (req, res, next) => {
  let aproductionconsolidated = await ProductionConsolidated.create(req.body);

  return res.status(200).json({
    message: "Successfully added!",
  });
});

// get Signle ProductionConsolidated => /api/productionconsolidated/:id
exports.getSingleProductionConsolidated = catchAsyncErrors(async (req, res, next) => {
  const id = req.params.id;

  let sproductionconsolidated = await ProductionConsolidated.findById(id);

  if (!sproductionconsolidated) {
    return next(new ErrorHandler("Production Consolidated not found!", 404));
  }
  return res.status(200).json({
    sproductionconsolidated,
  });
});

// update ProductionConsolidated by id => /api/productionconsolidated/:id
exports.updateProductionConsolidated = catchAsyncErrors(async (req, res, next) => {
  const id = req.params.id;
  if (!uproductionconsolidated) {
    return next(new ErrorHandler("Production Consolidated not found!", 404));
  }
  return res.status(200).json({ message: "Updated successfully" });
});

// delete ProductionConsolidated by id => /api/productionconsolidated/:id
exports.deleteProductionConsolidated = catchAsyncErrors(async (req, res, next) => {
  const id = req.params.id;

  let dproductionconsolidated = await ProductionConsolidated.findByIdAndRemove(id);

  if (!dproductionconsolidated) {
    return next(new ErrorHandler("Production Consolidated  not found!", 404));
  }
  return res.status(200).json({ message: "Deleted successfully" });
});
