const Manualstock = require("../../../model/modules/stockpurchase/manualstockentry");
const User = require("../../../model/login/auth");
const ErrorHandler = require("../../../utils/errorhandler");
const catchAsyncErrors = require("../../../middleware/catchAsyncError");

//get All Manualstocks =>/api/manualstock
exports.getAllManualstock = catchAsyncErrors(async (req, res, next) => {
  let manualstock;
  try {
    manualstock = await Manualstock.find();
  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!manualstock) {
    return next(new ErrorHandler("Manualstock not found!", 404));
  }
  return res.status(200).json({
    manualstock,
  });
});


exports.getAllManualstockAccess = catchAsyncErrors(async (req, res, next) => {
  let manualstock;
  try {
    const { assignbranch } = req.body;
    let filterQuery = {};
    // Construct the filter query based on the assignbranch array
    const branchFilter = assignbranch.map((branchObj) => ({
      branch: branchObj.branch,
      company: branchObj.company,
      unit: branchObj.unit,
    }));

    // Use $or to filter incomes that match any of the branch, company, and unit combinations
    if (branchFilter.length > 0) {
      filterQuery = { $or: branchFilter };
    }

    manualstock = await Manualstock.find(filterQuery);
  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!manualstock) {
    return next(new ErrorHandler("Manualstock not found!", 404));
  }
  return res.status(200).json({
    manualstock,
  });
});

//create new manualstock => /api/manualstock/new
exports.addManualstock = catchAsyncErrors(async (req, res, next) => {
  let amanualstock = await Manualstock.create(req.body);
  return res.status(200).json({
    message: "Successfully added!",
  });
});

// get Single manualstock=> /api/manualstock/:id
exports.getSingleManualstock = catchAsyncErrors(async (req, res, next) => {
  const id = req.params.id;
  let smanualstock = await Manualstock.findById(id);
  if (!smanualstock) {
    return next(new ErrorHandler("Manualstock not found", 404));
  }
  return res.status(200).json({
    smanualstock,
  });
});
//update manualstock by id => /api/manualstock/:id
exports.updateManualstock = catchAsyncErrors(async (req, res, next) => {
  const id = req.params.id;
  let umanualstock = await Manualstock.findByIdAndUpdate(id, req.body);
  if (!umanualstock) {
    return next(new ErrorHandler("Manualstock not found", 404));
  }

  return res.status(200).json({ message: "Updated successfully" });
});
//delete manualstock by id => /api/manualstock/:id
exports.deleteManualstock = catchAsyncErrors(async (req, res, next) => {
  const id = req.params.id;
  let dmanualstock = await Manualstock.findByIdAndRemove(id);
  if (!dmanualstock) {
    return next(new ErrorHandler("Manualstock not found", 404));
  }

  return res.status(200).json({ message: "Deleted successfully" });
});

exports.Manualstocktrasnferfilter = catchAsyncErrors(async (req, res, next) => {
  let manualstocks;
  try {
    manualstocks = await Manualstock.find({ productname: req.body.productname, branch: req.body.branch, producthead: req.body.producthead }, { productname: 1, producthead: 1, quantity: 1 });
  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!manualstocks) {
    return next(new ErrorHandler("Manualstock not found!", 404));
  }
  return res.status(200).json({
    manualstocks,
  });
});


