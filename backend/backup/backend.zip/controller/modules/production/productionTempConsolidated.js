const ProductionTempConsolidated = require("../../../model/modules/production/productionTempConsolidated");
const TempPointsUpload = require("../../../model/modules/production/tempPointsUpload");
const ErrorHandler = require("../../../utils/errorhandler");
const catchAsyncErrors = require("../../../middleware/catchAsyncError");

// get All ProductionTempConsolidated Name => /api/productiontempConsolidateds
exports.getAllProductionTempConsolidated = catchAsyncErrors(async (req, res, next) => {
    let productiontempConsolidated;
    try {
        productiontempConsolidated = await ProductionTempConsolidated.find();
    } catch (err) {
        return next(new ErrorHandler("Records not found!", 404));
    }
    if (!productiontempConsolidated) {
        return next(new ErrorHandler("Production Temp Consolidated  not found!", 404));
    }
    return res.status(200).json({
        // count: products.length,
        productiontempConsolidated,
    });
});


// get All ProductionTempConsolidated Name => /api/productiontempConsolidateds
exports.getFilterProductionTempConsolidated = catchAsyncErrors(async (req, res, next) => {
    let productiontempConsolidated, daypoints, ans;
    try {
        productiontempConsolidated = await ProductionTempConsolidated.find({ _id: req.body.id });
        daypoints = await TempPointsUpload.find();
        let answer = daypoints.map((data) => data.uploaddata).flat();
        ans = answer.filter(data => data.date >= productiontempConsolidated[0].fromdate && data.date <= productiontempConsolidated[0].todate)
    } catch (err) {
        return next(new ErrorHandler("Records not found!", 404));
    }
    return res.status(200).json({
        // count: products.length,
        productiontempConsolidated, ans
    });
});
// Create new ProductionTempConsolidated=> /api/productiontempConsolidated/new
exports.addProductionTempConsolidated = catchAsyncErrors(async (req, res, next) => {
    let aproductiontempConsolidated = await ProductionTempConsolidated.create(req.body);

    return res.status(200).json({
        message: "Successfully added!",
    });
});

// get Signle ProductionTempConsolidated => /api/productiontempConsolidated/:id
exports.getSingleProductionTempConsolidated = catchAsyncErrors(async (req, res, next) => {
    const id = req.params.id;

    let sproductiontempConsolidated = await ProductionTempConsolidated.findById(id);

    if (!sproductiontempConsolidated) {
        return next(new ErrorHandler("Production Temp Consolidated  not found!", 404));
    }
    return res.status(200).json({
        sproductiontempConsolidated,
    });
});

// update ProductionTempConsolidated by id => /api/productiontempConsolidated/:id
exports.updateProductionTempConsolidated = catchAsyncErrors(async (req, res, next) => {
    const id = req.params.id;
    if (!uproductiontempConsolidated) {
        return next(new ErrorHandler("Production Temp Consolidated  not found!", 404));
    }
    return res.status(200).json({ message: "Updated successfully" });
});

// delete ProductionTempConsolidated by id => /api/productiontempConsolidated/:id
exports.deleteProductionTempConsolidated = catchAsyncErrors(async (req, res, next) => {
    const id = req.params.id;

    let dproductiontempConsolidated = await ProductionTempConsolidated.findByIdAndRemove(id);

    if (!dproductiontempConsolidated) {
        return next(new ErrorHandler("Production Temp Consolidated  not found!", 404));
    }
    return res.status(200).json({ message: "Deleted successfully" });
});
