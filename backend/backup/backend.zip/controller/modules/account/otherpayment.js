const OtherPayments = require("../../../model/modules/account/otherpayment");
const ErrorHandler = require("../../../utils/errorhandler");
const catchAsyncErrors = require("../../../middleware/catchAsyncError");

//get All aotherpayments =>/api/allotherpayments
exports.getAllOtherPayments = catchAsyncErrors(async (req, res, next) => {
  let otherpayments;
  try {
    const { assignbranch } = req.body;

    // Construct the filter query based on the assignbranch array
    const branchFilter = assignbranch.map((branchObj) => ({
      branchname: branchObj.branch,
      company: branchObj.company,
    }));

    // Use $or to filter incomes that match any of the branch, company, and unit combinations
    const filterQuery = { $or: branchFilter };
    otherpayments = await OtherPayments.find(filterQuery);
  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!otherpayments) {
    return next(new ErrorHandler("Company not found!", 404));
  }

  // Add serial numbers to the otherpayments
  const allotherpayments = otherpayments.map((payments, index) => ({
    serialNumber: index + 1,
    ...payments.toObject(),
  }));

  return res.status(200).json({
    otherpayments: allotherpayments,
  });
});
exports.skippedOtherPayments = async (req, res) => {
  try {
    let totalProjects, result;
    const { page, pageSize, assignbranch } = req.body;

    // Construct the filter query based on the assignbranch array
    const branchFilter = assignbranch.map((branchObj) => ({
      branchname: branchObj.branch,
      company: branchObj.company,
    }));

    // Use $or to filter incomes that match any of the branch, company, and unit combinations
    const filterQuery = { $or: branchFilter };
    totalProjects = await OtherPayments.countDocuments(filterQuery);

    // Execute the filter query on the User model
    allusers = await OtherPayments.find(filterQuery)
      .skip((page - 1) * pageSize)
      .limit(parseInt(pageSize));

    result = allusers;
    return res.status(200).json({
      allusers,
      totalProjects,
      result,
      currentPage: page,
      totalPages: Math.ceil(totalProjects / pageSize),
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Internal server error" });
  }
};

//create new otherpayments => /api/otherpayment/new
exports.addOtherPayments = catchAsyncErrors(async (req, res, next) => {
  let aotherpayments = await OtherPayments.create(req.body);
  return res.status(200).json({
    message: "Successfully added!",
  });
});

// get Single otherpayment => /api/otherpayment/:id
exports.getSingleotherpayment = catchAsyncErrors(async (req, res, next) => {
  const id = req.params.id;
  let sotherpayment = await OtherPayments.findById(id);
  if (!sotherpayment) {
    return next(new ErrorHandler("company not found", 404));
  }
  return res.status(200).json({
    sotherpayment,
  });
});
//update sotherpayment by id => /api/otherpayment/:id
exports.updatesOtherpayment = catchAsyncErrors(async (req, res, next) => {
  const id = req.params.id;
  let uotherpayment = await OtherPayments.findByIdAndUpdate(id, req.body);
  if (!uotherpayment) {
    return next(new ErrorHandler("company not found", 404));
  }

  return res
    .status(200)
    .json({ message: "Updated successfully", uotherpayment });
});

//delete dotherpayment by id => /api/otherpayment/:id
exports.deletesOtherpayment = catchAsyncErrors(async (req, res, next) => {
  const id = req.params.id;
  let dotherpayment = await OtherPayments.findByIdAndRemove(id);
  if (!dotherpayment) {
    return next(new ErrorHandler("company not found", 404));
  }
  return res.status(200).json({ message: "Deleted successfully" });
});