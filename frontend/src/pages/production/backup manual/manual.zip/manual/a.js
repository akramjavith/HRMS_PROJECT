//Hierarchy- Hierarchy Based Employee Status
exports.getHierarchyBasedEmployeeWorkstationhira = catchAsyncErrors(async (req, res, next) => {
    let resultArray,
        user,
        result1,
        ans1D,
        i = 1,
        result2,
        result3,
        result4,
        result5,
        result6,
        dataCheck,
        userFilter,
        result,
        hierarchyFilter,
        answerDef,
        hierarchyFinal,
        hierarchy,
        hierarchyDefList,
        resultAccessFilter,
        branch,
        hierarchySecond,
        overallMyallList,
        hierarchyMap,
        resulted,
        resultedTeam,
        myallTotalNames;

    try {

        let levelFinal = req.body?.sector === "all" ? ["Primary", "Secondary", "Tertiary"] : [req.body?.sector]
        let answer = await Hirerarchi.aggregate([
            {
                $match: {
                    supervisorchoose:
                        req?.body?.username, // Match supervisorchoose with username
                    level: { $in: levelFinal } // Corrected unmatched quotation mark
                }
            },
            {
                $lookup: {
                    from: "reportingheaders",
                    let: {
                        teamControlsArray: {
                            $ifNull: ["$pagecontrols", []]
                        }
                    },
                    pipeline: [
                        {
                            $match: {
                                $expr: {
                                    $and: [
                                        {
                                            $in: [
                                                "$name",
                                                "$$teamControlsArray"
                                            ]
                                        }, // Check if 'name' is in 'teamcontrols' array
                                        {
                                            $in: [
                                                req?.body?.pagename,
                                                "$reportingnew" // Check if 'menuteamloginstatus' is in 'reportingnew' array
                                            ]
                                        } // Additional condition for reportingnew array
                                    ]
                                }
                            }
                        }
                    ],
                    as: "reportData" // The resulting matched documents will be in this field
                }
            },
            {
                $project: {
                    supervisorchoose: 1,
                    employeename: 1,
                    reportData: 1
                }
            }
        ]);
        let restrictList = answer?.filter(data => data?.reportData?.length > 0)?.flatMap(Data => Data?.employeename)


        result = await User.find(
            {
                enquirystatus: {
                    $nin: ["Enquiry Purpose"],
                },
                resonablestatus: {
                    $nin: ["Not Joined", "Postponed", "Rejected", "Closed", "Releave Employee", "Absconded", "Hold", "Terminate"],
                },
            },
            {
                unit: 1,
                branch: 1,
                designation: 1,
                department: 1,
                dob: 1,
                company: 1,
                empcode: 1,
                companyname: 1,
                team: 1,
                username: 1,
                workmode: 1,
                employeecount: 1,
                workstation: 1,
                enableworkstation: 1,
                wordcheck: 1,
                workstationinput: 1,
                workstationofficestatus: 1,
                wfhstatus: 1,
                wfhcount: 1, loginUserStatus: 1
            }
        );

        // Accordig to sector and list filter process
        hierarchyFilter = await Hirerarchi.find({ level: req.body.sector });
        userFilter = hierarchyFilter.filter((data) => data.supervisorchoose.includes(req.body.username)).map((data) => data.employeename);
        hierarchyDefList = await Hirerarchi.find();
        user = await User.find({ companyname: req.body.username });
        const userFilt = user.length > 0 && user[0].designation;
        const desiGroup = await Designation.find();
        let HierarchyFilt = req.body.sector === "all" ?
            hierarchyDefList.filter((data) => data.supervisorchoose.includes(req.body.username)).map((data) => data.designationgroup) :
            hierarchyFilter.filter((data) => data.supervisorchoose.includes(req.body.username)).map((data) => data.designationgroup);
        const DesifFilter = desiGroup.filter((data) => HierarchyFilt.includes(data.group));
        const desigName = DesifFilter.length > 0 && DesifFilter[0].name;
        const SameDesigUser = HierarchyFilt.includes("All") ? true : userFilt === desigName;
        //Default Loading of List
        answerDef = hierarchyDefList.filter((data) => data.supervisorchoose.includes(req.body.username)).map((data) => data.employeename);

        hierarchyFinal = req.body.sector === "all" ? (answerDef.length > 0 ? [].concat(...answerDef) : []) : hierarchyFilter.length > 0 ? [].concat(...userFilter) : [];

        hierarchyMap = hierarchyFinal.length > 0 ? hierarchyFinal : [];


        //solo
        ans1D = req.body.sector === "all" ? (answerDef.length > 0 ? hierarchyDefList.filter((data) => data.supervisorchoose.includes(req.body.username)) : []) : hierarchyFilter.length > 0 ? hierarchyFilter.filter((data) => data.supervisorchoose.includes(req.body.username)) : [];
        result1 =
            ans1D.length > 0
                ? result
                    .map((item1) => {
                        const matchingItem2 = ans1D.find((item2) => item2.employeename.includes(item1.companyname));

                        if (matchingItem2) {
                            const plainItem1 = item1.toObject ? item1.toObject() : item1;
                            return { ...plainItem1, level: req.body.sector + "-" + matchingItem2.control };
                            //   return { ...item1, level: req.body.sector + "-" + matchingItem2.control };
                        }
                    })
                    .filter((item) => item !== undefined)
                : [];

        resulted = result1;


        //team
        let branches = [];
        hierarchySecond = await Hirerarchi.find();

        const subBranch =
            hierarchySecond.length > 0
                ? hierarchySecond
                    .filter((item) => item.supervisorchoose.some((name) => hierarchyMap.includes(name)))
                    .map((item) => item.employeename)
                    .flat()
                : "";

        const answerFilterExcel = hierarchySecond.length > 0 ? hierarchySecond.filter((item) => item.supervisorchoose.some((name) => hierarchyMap.includes(name))) : [];

        result2 =
            answerFilterExcel.length > 0
                ? result
                    .map((item1) => {
                        const matchingItem2 = answerFilterExcel.find((item2) => item2.employeename.includes(item1.companyname));
                        if (matchingItem2) {
                            // If a match is found, inject the control property into the corresponding item in an1
                            const plainItem1 = item1.toObject ? item1.toObject() : item1;
                            return { ...plainItem1, level: req.body.sector + "-" + matchingItem2.control };
                            // return { ...item1, level: req.body.sector + "-" + matchingItem2.control };
                        }
                    })
                    .filter((item) => item !== undefined)
                : [];
        branches.push(...subBranch);

        const ans =
            subBranch.length > 0
                ? hierarchySecond
                    .filter((item) => item.supervisorchoose.some((name) => subBranch.includes(name)))
                    .map((item) => item.employeename)
                    .flat()
                : "";
        const answerFilterExcel2 = subBranch.length > 0 ? hierarchySecond.filter((item) => item.supervisorchoose.some((name) => subBranch.includes(name))) : [];

        result3 =
            answerFilterExcel2.length > 0
                ? result
                    .map((item1) => {
                        const matchingItem2 = answerFilterExcel2.find((item2) => item2.employeename.includes(item1.companyname));
                        if (matchingItem2) {
                            const plainItem1 = item1.toObject ? item1.toObject() : item1;
                            return { ...plainItem1, level: req.body.sector + "-" + matchingItem2.control };
                            // If a match is found, inject the control property into the corresponding item in an1
                            // return { ...item1, level: req.body.sector + "-" + matchingItem2.control };
                        }
                    })
                    .filter((item) => item !== undefined)
                : [];
        branches.push(...ans);

        const loop3 =
            ans.length > 0
                ? hierarchySecond
                    .filter((item) => item.supervisorchoose.some((name) => ans.includes(name)))
                    .map((item) => item.employeename)
                    .flat()
                : "";

        const answerFilterExcel3 = ans.length > 0 ? hierarchySecond.filter((item) => item.supervisorchoose.some((name) => ans.includes(name))) : [];

        result4 =
            answerFilterExcel3.length > 0
                ? result
                    .map((item1) => {
                        const matchingItem2 = answerFilterExcel3?.find((item2) => item2.employeename.includes(item1.companyname));
                        if (matchingItem2) {
                            const plainItem1 = item1.toObject ? item1.toObject() : item1;
                            return { ...plainItem1, level: req.body.sector + "-" + matchingItem2.control };
                            // If a match is found, inject the control property into the corresponding item in an1
                            // return { ...item1, level: req.body.sector + "-" + matchingItem2.control };
                        }
                    })
                    .filter((item) => item !== undefined)
                : [];
        branches.push(...loop3);

        const loop4 =
            loop3.length > 0
                ? hierarchySecond
                    .filter((item) => item.supervisorchoose.some((name) => loop3.includes(name)))
                    .map((item) => item.employeename)
                    .flat()
                : [];
        const answerFilterExcel4 = loop3.length > 0 ? hierarchySecond.filter((item) => item.supervisorchoose.some((name) => loop3.includes(name))) : [];
        result5 =
            answerFilterExcel4.length > 0
                ? result
                    .map((item1) => {
                        const matchingItem2 = answerFilterExcel4?.find((item2) => item2.employeename.includes(item1.companyname));
                        if (matchingItem2) {
                            const plainItem1 = item1.toObject ? item1.toObject() : item1;
                            return { ...plainItem1, level: req.body.sector + "-" + matchingItem2.control };
                            // If a match is found, inject the control property into the corresponding item in an1
                            // return { ...item1, level: req.body.sector + "-" + matchingItem2.control };
                        }
                    })
                    .filter((item) => item !== undefined)
                : [];
        branches.push(...loop4);

        const loop5 =
            loop4.length > 0
                ? hierarchySecond
                    .filter((item) => item.supervisorchoose.some((name) => loop4.includes(name)))
                    .map((item) => item.employeename)
                    .flat()
                : "";
        const answerFilterExcel5 = loop4.length > 0 ? hierarchySecond.filter((item) => item.supervisorchoose.some((name) => loop4.includes(name))) : [];
        result6 =
            answerFilterExcel5.length > 0
                ? result
                    .map((item1) => {
                        const matchingItem2 = answerFilterExcel5?.find((item2) => item2.employeename.includes(item1.companyname));
                        if (matchingItem2) {
                            const plainItem1 = item1.toObject ? item1.toObject() : item1;
                            return { ...plainItem1, level: req.body.sector + "-" + matchingItem2.control };
                            // If a match is found, inject the control property into the corresponding item in an1
                            // return { ...item1, level: req.body.sector + "-" + matchingItem2.control };
                        }
                    })
                    .filter((item) => item !== undefined)
                : [];
        branches.push(...loop5);

        resultedTeam = [...result2, ...result3, ...result4, ...result5, ...result6];
        //overall Teams List
        myallTotalNames = [...hierarchyMap, ...branches];
        overallMyallList = [...resulted, ...resultedTeam];
        const restrictTeam = await Hirerarchi.aggregate([
            {
                $match: {
                    supervisorchoose:
                        { $in: restrictList }, // Match supervisorchoose with username
                    level: { $in: levelFinal } // Corrected unmatched quotation mark
                }
            },
            {
                $lookup: {
                    from: "reportingheaders",
                    let: {
                        teamControlsArray: {
                            $ifNull: ["$pagecontrols", []]
                        }
                    },
                    pipeline: [
                        {
                            $match: {
                                $expr: {
                                    $and: [
                                        {
                                            $in: [
                                                "$name",
                                                "$$teamControlsArray"
                                            ]
                                        }, // Check if 'name' is in 'teamcontrols' array
                                        {
                                            $in: [
                                                req?.body?.pagename,
                                                "$reportingnew" // Check if 'menuteamloginstatus' is in 'reportingnew' array
                                            ]
                                        } // Additional condition for reportingnew array
                                    ]
                                }
                            }
                        }
                    ],
                    as: "reportData" // The resulting matched documents will be in this field
                }
            },
            {
                $project: {
                    supervisorchoose: 1,
                    employeename: 1,
                    reportData: 1
                }
            }
        ]);
        let restrictListTeam = restrictTeam?.filter(data => data?.reportData?.length > 0)?.flatMap(Data => Data?.employeename)
        let overallRestrictList = req.body.hierachy === "myhierarchy" ? restrictList : req.body.hierachy === "allhierarchy" ? restrictListTeam : [...restrictList, ...restrictListTeam];
        const resultAccessFilterHierarchy = req.body.hierachy === "myhierarchy" ? resulted : req.body.hierachy === "allhierarchy" ? resultedTeam : overallMyallList;
        resultAccessFilter = overallRestrictList?.length > 0 ? resultAccessFilterHierarchy?.filter(data => overallRestrictList?.includes(data?.companyname)) : [];

    } catch (err) {
        return next(new ErrorHandler("Records not found!", 404));
    }
    if (!result) {
        return next(new ErrorHandler("No data found!", 404));
    }
    return res.status(200).json({
        result,
        ans1D,
        result1,
        resulted,
        resultedTeam,
        branch,
        hierarchy,
        overallMyallList,
        resultAccessFilter,
        hierarchyFilter,
        user,
        dataCheck,
        userFilter,
        resultArray,
    });
});