const AssetWorkGrp = require("../../../model/modules/account/assetworkstationgrouping");
const User = require("../../../model/login/auth");
const ErrorHandler = require("../../../utils/errorhandler");
const catchAsyncErrors = require("../../../middleware/catchAsyncError");

//get All AssetWorkGrps =>/api/assetworkstationgrouping
exports.getAllAssetWorkGrp = catchAsyncErrors(async (req, res, next) => {
    let assetworkstationgrouping;
    try {
        assetworkstationgrouping = await AssetWorkGrp.find();
    } catch (err) {
        return next(new ErrorHandler("Records not found!", 404));
    }
    if (!assetworkstationgrouping) {
        return next(new ErrorHandler("AssetWorkGrp not found!", 404));
    }
    return res.status(200).json({
        assetworkstationgrouping,
    });
});

//create new assetworkstationgrouping => /api/assetworkstationgrouping/new
exports.addAssetWorkGrp = catchAsyncErrors(async (req, res, next) => {
    let aassetworkstationgrouping = await AssetWorkGrp.create(req.body);
    return res.status(200).json({
        message: "Successfully added!",
    });
});

// get Single assetworkstationgrouping=> /api/assetworkstationgrouping/:id
exports.getSingleAssetWorkGrp = catchAsyncErrors(async (req, res, next) => {
    const id = req.params.id;
    let sassetworkstationgrouping = await AssetWorkGrp.findById(id);
    if (!sassetworkstationgrouping) {
        return next(new ErrorHandler("AssetWorkGrp not found", 404));
    }
    return res.status(200).json({
        sassetworkstationgrouping,
    });
});
//update assetworkstationgrouping by id => /api/assetworkstationgrouping/:id
exports.updateAssetWorkGrp = catchAsyncErrors(async (req, res, next) => {
    const id = req.params.id;
    let uassetworkstationgrouping = await AssetWorkGrp.findByIdAndUpdate(id, req.body);
    if (!uassetworkstationgrouping) {
        return next(new ErrorHandler("AssetWorkGrp not found", 404));
    }

    return res.status(200).json({ message: "Updated successfully" });
});
//delete assetworkstationgrouping by id => /api/assetworkstationgrouping/:id
exports.deleteAssetWorkGrp = catchAsyncErrors(async (req, res, next) => {
    const id = req.params.id;
    let dassetworkstationgrouping = await AssetWorkGrp.findByIdAndRemove(id);
    if (!dassetworkstationgrouping) {
        return next(new ErrorHandler("AssetWorkGrp not found", 404));
    }

    return res.status(200).json({ message: "Deleted successfully" });
});


exports.getAllAssetWorkGrpAcces = catchAsyncErrors(async (req, res, next) => {
    let assetworkstationgrouping;
    try {
        const { assignbranch } = req.body;
        let filterQuery = {};
        // Construct the filter query based on the assignbranch array
        const branchFilter = assignbranch.map((branchObj) => ({
            branch: branchObj.branch,
            company: branchObj.company,
            unit: branchObj.unit,
        }));

        // Use $or to filter incomes that match any of the branch, company, and unit combinations
        if (branchFilter.length > 0) {
            filterQuery = { $or: branchFilter };
        }
        assetworkstationgrouping = await AssetWorkGrp.find(filterQuery);
    } catch (err) {
        return next(new ErrorHandler("Records not found!", 404));
    }
    if (!assetworkstationgrouping) {
        return next(new ErrorHandler("AssetWorkGrp not found!", 404));
    }
    return res.status(200).json({
        assetworkstationgrouping,
    });
});

exports.getAllEmployeeassetAccess = catchAsyncErrors(async (req, res, next) => {
    let employeeassets;
    try {
        const { assignbranch } = req.body;
        let filterQuery = {};
        // Construct the filter query based on the assignbranch array
        const branchFilter = assignbranch.map((branchObj) => ({
            branch: branchObj.branch,
            company: branchObj.company,
            unit: branchObj.unit,
        }));
        const branchFilterTo = assignbranch.map((branchObj) => ({
            branchto: branchObj.branch,
            companyto: branchObj.company,
            unitto: branchObj.unit,
        }));

        // Use $or to filter incomes that match any of the branch, company, and unit combinations
        // Use $or to filter incomes that match any of the branch, company, and unit combinations
        if (branchFilter.length > 0 || branchFilterTo.length > 0) {
            filterQuery = {
                $or: [...branchFilter, ...branchFilterTo],
            };
        }
        employeeassets = await Employeeasset.find(filterQuery);
    } catch (err) {
        return next(new ErrorHandler("Records not found!", 404));
    }
    if (!employeeassets) {
        return next(new ErrorHandler("Employeeasset not found!", 404));
    }
    return res.status(200).json({
        employeeassets,
    });
});