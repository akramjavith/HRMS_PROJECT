const AssetMaterialIP = require("../../../model/modules/account/assetmaterialip");
const User = require("../../../model/login/auth");
const ErrorHandler = require("../../../utils/errorhandler");
const catchAsyncErrors = require("../../../middleware/catchAsyncError");

//get All AssetMaterialIPs =>/api/assetmaterialip
exports.getAllAssetMaterialIP = catchAsyncErrors(async (req, res, next) => {
    let assetmaterialip;
    try {
        assetmaterialip = await AssetMaterialIP.find();
    } catch (err) {
        return next(new ErrorHandler("Records not found!", 404));
    }
    if (!assetmaterialip) {
        return next(new ErrorHandler("AssetMaterialIP not found!", 404));
    }
    return res.status(200).json({
        assetmaterialip,
    });
});



exports.getAllAssetMaterialIPLimited = catchAsyncErrors(async (req, res, next) => {
    let assetmaterialip;
    try {
        assetmaterialip = await AssetMaterialIP.find({}, {
            company: 1, branch: 1, unit: 1, component: 1, floor: 1,

            location: 1, area: 1, assetmaterial: 1, assetmaterialcheck: 1, subcomponents: 1, ip: 1, ebusage: 1, empdistribution: 1,
            maintenance: 1, uniqueid: 1
        });
    } catch (err) {
        return next(new ErrorHandler("Records not found!", 404));
    }
    if (!assetmaterialip) {
        return next(new ErrorHandler("AssetMaterialIP not found!", 404));
    }
    return res.status(200).json({
        assetmaterialip,
    });
});

//create new assetmaterialip => /api/assetmaterialip/new
exports.addAssetMaterialIP = catchAsyncErrors(async (req, res, next) => {
    let aassetmaterialip = await AssetMaterialIP.create(req.body);
    return res.status(200).json({
        message: "Successfully added!",
    });
});

// get Single assetmaterialip=> /api/assetmaterialip/:id
exports.getSingleAssetMaterialIP = catchAsyncErrors(async (req, res, next) => {
    const id = req.params.id;
    let sassetmaterialip = await AssetMaterialIP.findById(id);
    if (!sassetmaterialip) {
        return next(new ErrorHandler("AssetMaterialIP not found", 404));
    }
    return res.status(200).json({
        sassetmaterialip,
    });
});
//update assetmaterialip by id => /api/assetmaterialip/:id
exports.updateAssetMaterialIP = catchAsyncErrors(async (req, res, next) => {
    const id = req.params.id;
    let uassetmaterialip = await AssetMaterialIP.findByIdAndUpdate(id, req.body);
    if (!uassetmaterialip) {
        return next(new ErrorHandler("AssetMaterialIP not found", 404));
    }

    return res.status(200).json({ message: "Updated successfully" });
});
//delete assetmaterialip by id => /api/assetmaterialip/:id
exports.deleteAssetMaterialIP = catchAsyncErrors(async (req, res, next) => {
    const id = req.params.id;
    let dassetmaterialip = await AssetMaterialIP.findByIdAndRemove(id);
    if (!dassetmaterialip) {
        return next(new ErrorHandler("AssetMaterialIP not found", 404));
    }

    return res.status(200).json({ message: "Deleted successfully" });
});


exports.getAllAssetMaterialIPLimitedAccess = catchAsyncErrors(async (req, res, next) => {
    let assetmaterialip;
    try {
        const { assignbranch } = req.body;
        let filterQuery = {};
        // Construct the filter query based on the assignbranch array
        const branchFilter = assignbranch.map((branchObj) => ({
            branch: branchObj.branch,
            company: branchObj.company,
            unit: branchObj.unit,
        }));

        // Use $or to filter incomes that match any of the branch, company, and unit combinations
        if (branchFilter.length > 0) {
            filterQuery = { $or: branchFilter };
        }
        assetmaterialip = await AssetMaterialIP.find(filterQuery, {
            company: 1, branch: 1, unit: 1, component: 1, floor: 1,

            location: 1, area: 1, assetmaterial: 1, assetmaterialcheck: 1, subcomponents: 1, ip: 1, ebusage: 1, empdistribution: 1,
            maintenance: 1, uniqueid: 1
        });
    } catch (err) {
        return next(new ErrorHandler("Records not found!", 404));
    }
    if (!assetmaterialip) {
        return next(new ErrorHandler("AssetMaterialIP not found!", 404));
    }
    return res.status(200).json({
        assetmaterialip,
    });
});